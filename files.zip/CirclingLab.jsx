import React, { useState, useEffect, useRef, useMemo } from "react";
import { Volume2, RotateCcw, Check, X, ChevronRight, Zap, Sparkles, Mic, Square, Puzzle, BookOpen, PenLine, Play, Languages, Eye, Plus } from "lucide-react";

/* ================================================================== */
/*  ENTITIES  (hand-built; Kai-Ti is the authority on the Chinese)     */
/* ================================================================== */
const E = {
  xm:     { id: "xm",     label: "小明", tones: [3, 2], emoji: "👦🏽", en: "Xiao Ming", full: "小明", note: "his NAME (like \u201CMike\u201D) \u2014 it doesn\u2019t mean \u201Cboy\u201D!" },
  mama:   { id: "mama",   label: "妈妈", tones: [1, 0], emoji: "👩🏽", en: "Mom", full: "妈妈" },
  hungry: { id: "hungry", label: "饿", tones: [4], emoji: "🤤", en: "hungry", full: "很饿" },
  happy:  { id: "happy",  label: "高兴", tones: [1, 4], emoji: "😄", en: "happy", full: "很高兴" },
  sad:    { id: "sad",    label: "难过", tones: [2, 4], emoji: "😢", en: "sad", full: "很难过" },
  baozi:  { id: "baozi",  label: "包子", tones: [1, 0], emoji: "🥟", en: "baozi", full: "包子" },
  apple:  { id: "apple",  label: "苹果", tones: [2, 3], emoji: "🍎", en: "an apple", full: "苹果" },
  store:  { id: "store",  label: "商店", tones: [1, 4], emoji: "🏪", en: "the store", full: "商店" },
  school: { id: "school", label: "学校", tones: [2, 4], emoji: "🏫", en: "school", full: "学校" },
};
const NOVELTY = [ // circle sound-alikes (identity only)
  { id: "pizza", emoji: "🍕", en: "pizza", full: "披萨" },
  { id: "coffee", emoji: "☕", en: "coffee", full: "咖啡" },
  { id: "kungfu", emoji: "🥋", en: "kung fu", full: "功夫" },
  { id: "choc", emoji: "🍫", en: "chocolate", full: "巧克力" },
  { id: "cola", emoji: "🥤", en: "cola", full: "可乐" },
];

/* ================================================================== */
/*  THE STORY — 8 sentences, each with its full pipeline config         */
/* ================================================================== */
const SENTENCES = [
  {
    key: "s1", sentence: { hz: "这是小明。", py: "Zhè shì Xiǎo Míng.", en: "This is Xiao Ming.", emoji: "👦🏽" },
    frame: "这是{}", frameEn: "this is {}", neg: "这不是小明",
    circle: { pool: ["xm", "mama"], types: ["yesno", "either", "who"], yesno: { hz: "这是小明吗?", en: "Is this Xiao Ming?" }, yesnoAsked: "xm", either: { hz: "这是小明还是妈妈?", en: "Is this Xiao Ming or Mom?" }, eitherOptions: ["xm", "mama"], who: { hz: "这是谁?", en: "Who is this?" }, novelty: true },
    youAre: "Xiao Ming 👦🏽",
    tri: [
      { first: true, role: "self", ask: "你是小明吗?", askEn: "Are YOU Xiao Ming?", answer: "对，我是小明。", ansPy: "Duì, wǒ shì Xiǎo Míng.", tokens: ["对", "我", "是", "小明"], accept: ["对我是小明", "我是小明", "是我是小明"], confirm: "对，你是小明。", confirmEn: "Right — you're Xiao Ming!" },
      { role: "self", ask: "你是妈妈吗?", askEn: "Are YOU Mom?", answer: "不是，我是小明。", ansPy: "Bú shì, wǒ shì Xiǎo Míng.", tokens: ["不是", "我", "是", "小明"], accept: ["不是我是小明", "我是小明", "我不是妈妈"], confirm: "对，你不是妈妈，你是小明。", confirmEn: "Right — you're not Mom, you're Xiao Ming!" },
      { role: "self", ask: "你是谁?", askEn: "Who are YOU?", answer: "我是小明。", ansPy: "Wǒ shì Xiǎo Míng.", tokens: ["我", "是", "小明"], accept: ["我是小明", "我不是妈妈"], confirm: "对，你是小明。", confirmEn: "Yes — you're Xiao Ming!" },
      { role: "mama", ask: "我是谁?", askEn: "Who am I?", answer: "你是妈妈。", ansPy: "Nǐ shì māma.", tokens: ["你", "是", "妈妈"], accept: ["你是妈妈", "我是小明你是妈妈"], confirm: "对，我是妈妈。", confirmEn: "Right — I'm Mom!" },
    ],
    read: { hz: "这是小明", tones: [4, 4, 3, 2], opts: ["This is Xiao Ming.", "This is Mom.", "Xiao Ming is hungry."], correct: 0 },
    readVariants: [
      { hz: "这是妈妈", opts: ["This is Mom.", "This is Xiao Ming.", "I am Xiao Ming."], correct: 0 },
      { hz: "这不是小明", opts: ["This is NOT Xiao Ming.", "This is Xiao Ming.", "This is Mom."], correct: 0 },
      { hz: "我是小明", opts: ["I am Xiao Ming.", "You are Xiao Ming.", "This is Mom."], correct: 0 },
    ],
    write: "这是小明",
    newWords: [{ hz: "这", tones: [4], en: "this" }, { hz: "是", tones: [4], en: "is" }, { hz: "小明", tones: [3, 2], en: "Xiao Ming" }, { hz: "妈妈", tones: [1, 0], en: "Mom" }, { hz: "你", tones: [3], en: "you" }, { hz: "我", tones: [3], en: "I / me" }],
  },
  {
    key: "s2", sentence: { hz: "小明很饿。", py: "Xiǎo Míng hěn è.", en: "Xiao Ming is very hungry.", emoji: "🤤" },
    frame: "小明{}", frameEn: "Xiao Ming is {}", neg: "小明不饿",
    circle: { pool: ["hungry", "happy", "sad"], types: ["yesno", "either", "who"], yesno: { hz: "小明饿吗?", en: "Is Xiao Ming hungry?" }, yesnoAsked: "hungry", either: { hz: "小明饿还是高兴?", en: "Is Xiao Ming hungry or happy?" }, eitherOptions: ["hungry", "happy"], who: { hz: "小明怎么样?", en: "How is Xiao Ming?" }, novelty: false },
    youAre: "Xiao Ming 👦🏽",
    tri: [
      { first: true, role: "self", ask: "你饿吗?", askEn: "Are you hungry?", answer: "我很饿。", ansPy: "Wǒ hěn è.", tokens: ["我", "很", "饿"], accept: ["我很饿", "饿", "我饿"], confirm: "对，你很饿。", confirmEn: "Right — you're hungry!" },
      { role: "self", ask: "你高兴吗?", askEn: "Are you happy?", answer: "不，我很饿。", ansPy: "Bù, wǒ hěn è.", tokens: ["不", "我", "很", "饿"], accept: ["不我很饿", "我很饿", "我不高兴"], confirm: "对，你不高兴，你很饿。", confirmEn: "Right — you're not happy, you're hungry!" },
      { role: "self", ask: "你怎么样?", askEn: "How are you?", answer: "我很饿。", ansPy: "Wǒ hěn è.", tokens: ["我", "很", "饿"], accept: ["我很饿"], confirm: "对，你很饿。", confirmEn: "Yep — you're hungry!" },
      { role: "self", ask: "你饿还是高兴?", askEn: "Are you hungry or happy?", answer: "我很饿。", ansPy: "Wǒ hěn è.", tokens: ["我", "很", "饿"], accept: ["我很饿"], confirm: "对，你很饿。", confirmEn: "You're hungry!" },
    ],
    read: { hz: "小明很饿", tones: [3, 2, 3, 4], opts: ["Xiao Ming is very hungry.", "Xiao Ming is very happy.", "Xiao Ming is very sad."], correct: 0 },
    readVariants: [
      { hz: "妈妈很高兴", opts: ["Mom is very happy.", "Mom is very hungry.", "Xiao Ming is very happy."], correct: 0 },
      { hz: "小明不高兴", opts: ["Xiao Ming is not happy.", "Xiao Ming is very happy.", "Mom is not happy."], correct: 0 },
      { hz: "我很饿", opts: ["I am very hungry.", "You are very hungry.", "I am very happy."], correct: 0 },
    ],
    write: "小明很饿",
    newWords: [{ hz: "很", tones: [3], en: "very" }, { hz: "饿", tones: [4], en: "hungry" }, { hz: "高兴", tones: [1, 4], en: "happy" }, { hz: "难过", tones: [2, 4], en: "sad" }],
  },
  {
    key: "s3", sentence: { hz: "他想吃包子。", py: "Tā xiǎng chī bāozi.", en: "He wants to eat baozi.", emoji: "🥟" },
    frame: "他想吃{}", frameEn: "he wants to eat {}", neg: "他不想吃包子",
    circle: { pool: ["baozi", "apple"], types: ["yesno", "either", "who"], yesno: { hz: "他想吃包子吗?", en: "Does he want to eat baozi?" }, yesnoAsked: "baozi", either: { hz: "他想吃包子还是苹果?", en: "Baozi or an apple?" }, eitherOptions: ["baozi", "apple"], who: { hz: "他想吃什么?", en: "What does he want to eat?" }, novelty: true },
    youAre: "Xiao Ming 👦🏽",
    tri: [
      { first: true, role: "self", ask: "你想吃包子吗?", askEn: "Do you want to eat baozi?", answer: "我想吃包子。", ansPy: "Wǒ xiǎng chī bāozi.", tokens: ["我", "想", "吃", "包子"], accept: ["我想吃包子", "想吃包子"], confirm: "对，你想吃包子。", confirmEn: "Right — you want baozi!" },
      { role: "self", ask: "你想吃苹果吗?", askEn: "Do you want an apple?", answer: "不，我想吃包子。", ansPy: "Bù, wǒ xiǎng chī bāozi.", tokens: ["不", "我", "想", "吃", "包子"], accept: ["不我想吃包子", "我想吃包子"], confirm: "对，你想吃包子，不想吃苹果。", confirmEn: "Right — baozi, not an apple!" },
      { role: "self", ask: "你想吃什么?", askEn: "What do you want to eat?", answer: "我想吃包子。", ansPy: "Wǒ xiǎng chī bāozi.", tokens: ["我", "想", "吃", "包子"], accept: ["我想吃包子"], confirm: "对，你想吃包子。", confirmEn: "Baozi it is!" },
    ],
    read: { hz: "他想吃包子", tones: [1, 3, 1, 1, 0], opts: ["He wants to eat baozi.", "He wants to eat an apple.", "He goes to the store."], correct: 0 },
    readVariants: [
      { hz: "我想吃苹果", opts: ["I want to eat an apple.", "I want to eat baozi.", "He wants to eat an apple."], correct: 0 },
      { hz: "妈妈想吃包子", opts: ["Mom wants to eat baozi.", "Xiao Ming wants to eat baozi.", "Mom wants to eat an apple."], correct: 0 },
      { hz: "他不想吃苹果", opts: ["He does NOT want to eat an apple.", "He wants to eat an apple.", "He doesn't want to eat baozi."], correct: 0 },
    ],
    write: "他想吃包子",
    newWords: [{ hz: "他", tones: [1], en: "he" }, { hz: "想", tones: [3], en: "want to" }, { hz: "吃", tones: [1], en: "eat" }, { hz: "包子", tones: [1, 0], en: "baozi" }, { hz: "苹果", tones: [2, 3], en: "apple" }],
  },
  {
    key: "s4", sentence: { hz: "他去商店。", py: "Tā qù shāngdiàn.", en: "He goes to the store.", emoji: "🏪" },
    frame: "他去{}", frameEn: "he goes to {}", neg: "他不去商店",
    circle: { pool: ["store", "school"], types: ["yesno", "either", "who"], yesno: { hz: "他去商店吗?", en: "Does he go to the store?" }, yesnoAsked: "store", either: { hz: "他去商店还是学校?", en: "The store or school?" }, eitherOptions: ["store", "school"], who: { hz: "他去哪儿?", en: "Where does he go?" }, novelty: true },
    youAre: "Xiao Ming 👦🏽",
    tri: [
      { first: true, role: "self", ask: "你去商店吗?", askEn: "Do you go to the store?", answer: "我去商店。", ansPy: "Wǒ qù shāngdiàn.", tokens: ["我", "去", "商店"], accept: ["我去商店", "去商店"], confirm: "对，你去商店。", confirmEn: "Right — you go to the store!" },
      { role: "self", ask: "你去哪儿?", askEn: "Where do you go?", answer: "我去商店。", ansPy: "Wǒ qù shāngdiàn.", tokens: ["我", "去", "商店"], accept: ["我去商店"], confirm: "对，你去商店。", confirmEn: "To the store!" },
      { role: "self", ask: "你去商店还是学校?", askEn: "The store or school?", answer: "我去商店。", ansPy: "Wǒ qù shāngdiàn.", tokens: ["我", "去", "商店"], accept: ["我去商店"], confirm: "对，你去商店。", confirmEn: "The store!" },
    ],
    read: { hz: "他去商店", tones: [1, 4, 1, 4], opts: ["He goes to the store.", "He goes to school.", "He wants baozi."], correct: 0 },
    readVariants: [
      { hz: "小明去学校", opts: ["Xiao Ming goes to school.", "Xiao Ming goes to the store.", "Mom goes to school."], correct: 0 },
      { hz: "妈妈去商店", opts: ["Mom goes to the store.", "Mom goes to school.", "Xiao Ming goes to the store."], correct: 0 },
      { hz: "我不去学校", opts: ["I do NOT go to school.", "I go to school.", "He doesn't go to the store."], correct: 0 },
    ],
    write: "他去商店",
    newWords: [{ hz: "去", tones: [4], en: "go" }, { hz: "商店", tones: [1, 4], en: "the store" }, { hz: "学校", tones: [2, 4], en: "school" }],
  },
  {
    key: "s5", sentence: { hz: "商店没有包子。", py: "Shāngdiàn méiyǒu bāozi.", en: "The store has no baozi.", emoji: "🏪" },
    frame: "商店没有{}", frameEn: "the store has no {}", neg: null,
    circle: { pool: ["baozi"], types: ["yesno"], yesno: { hz: "商店有包子吗?", en: "Does the store have baozi?" }, yesnoAsked: "baozi", invert: true, novelty: false },
    youAre: "the store 🏪", role: "narrator",
    tri: [
      { first: true, role: "narrator", ask: "商店有包子吗?", askEn: "Does the store have baozi?", answer: "没有，商店没有包子。", ansPy: "Méiyǒu, shāngdiàn méiyǒu bāozi.", tokens: ["没有", "商店", "包子"], accept: ["没有商店没有包子", "商店没有包子", "没有"], confirm: "对，商店没有包子。", confirmEn: "Right — the store has no baozi." },
      { role: "narrator", ask: "商店有苹果吗?", askEn: "Does the store have an apple?", answer: "没有。", ansPy: "Méiyǒu.", tokens: ["没有"], accept: ["没有", "商店没有苹果"], confirm: "对，没有。", confirmEn: "Right — it doesn't." },
      { role: "narrator", ask: "商店有什么?", askEn: "What does the store have?", answer: "没有包子。", ansPy: "Méiyǒu bāozi.", tokens: ["没有", "包子"], accept: ["没有包子", "商店没有包子"], confirm: "对，没有包子。", confirmEn: "No baozi." },
    ],
    read: { hz: "商店没有包子", tones: [1, 4, 2, 3, 1, 0], opts: ["The store has no baozi.", "The store has baozi.", "Mom has baozi."], correct: 0 },
    readVariants: [
      { hz: "商店没有苹果", opts: ["The store has no apples.", "The store has no baozi.", "The store has apples."], correct: 0 },
      { hz: "我没有包子", opts: ["I don't have baozi.", "I have baozi.", "The store has no baozi."], correct: 0 },
      { hz: "他有苹果", opts: ["He has an apple.", "He has no apple.", "He has baozi."], correct: 0 },
    ],
    write: "商店没有包子",
    newWords: [{ hz: "没有", tones: [2, 3], en: "doesn't have" }, { hz: "有", tones: [3], en: "have" }],
  },
  {
    key: "s6", sentence: { hz: "小明很难过。", py: "Xiǎo Míng hěn nánguò.", en: "Xiao Ming is very sad.", emoji: "😢" },
    frame: "小明{}", frameEn: "Xiao Ming is {}", neg: "小明不难过",
    circle: { pool: ["sad", "happy", "hungry"], types: ["yesno", "either", "who"], yesno: { hz: "小明难过吗?", en: "Is Xiao Ming sad?" }, yesnoAsked: "sad", either: { hz: "小明难过还是高兴?", en: "Sad or happy?" }, eitherOptions: ["sad", "happy"], who: { hz: "小明怎么样?", en: "How is Xiao Ming?" }, novelty: false },
    youAre: "Xiao Ming 👦🏽",
    tri: [
      { first: true, role: "self", ask: "你难过吗?", askEn: "Are you sad?", answer: "我很难过。", ansPy: "Wǒ hěn nánguò.", tokens: ["我", "很", "难过"], accept: ["我很难过", "难过", "我难过"], confirm: "对，你很难过。", confirmEn: "Right — you're sad." },
      { role: "self", ask: "你高兴吗?", askEn: "Are you happy?", answer: "不,我很难过。", ansPy: "Bù, wǒ hěn nánguò.", tokens: ["不", "我", "很", "难过"], accept: ["不我很难过", "我很难过", "我不高兴"], confirm: "对，你不高兴，你很难过。", confirmEn: "Right — not happy, sad." },
      { role: "self", ask: "你怎么样?", askEn: "How are you?", answer: "我很难过。", ansPy: "Wǒ hěn nánguò.", tokens: ["我", "很", "难过"], accept: ["我很难过"], confirm: "对，你很难过。", confirmEn: "You're sad." },
    ],
    read: { hz: "小明很难过", tones: [3, 2, 3, 2, 4], opts: ["Xiao Ming is very sad.", "Xiao Ming is very happy.", "Xiao Ming is very hungry."], correct: 0 },
    readVariants: [
      { hz: "他不高兴", opts: ["He is not happy.", "He is very happy.", "He is not sad."], correct: 0 },
      { hz: "我很难过", opts: ["I am very sad.", "I am very happy.", "You are very sad."], correct: 0 },
      { hz: "小明不吃苹果", opts: ["Xiao Ming does not eat apples.", "Xiao Ming eats apples.", "Xiao Ming doesn't eat baozi."], correct: 0 },
    ],
    write: "小明很难过",
    newWords: [],
  },
  {
    key: "s7", sentence: { hz: "妈妈说：“我有包子！”", py: "Māma shuō: “Wǒ yǒu bāozi!”", en: 'Mom says: "I have baozi!"', emoji: "👩🥟" },
    frame: "{}有包子", frameEn: "{} has baozi", neg: null,
    circle: { pool: ["mama", "xm"], types: ["yesno", "who"], yesno: { hz: "妈妈有包子吗?", en: "Does Mom have baozi?" }, yesnoAsked: "mama", who: { hz: "谁有包子?", en: "Who has baozi?" }, whoOptions: ["mama", "xm"], novelty: true },
    youAre: "Mom 👩🏽", role: "asMama",
    tri: [
      { first: true, role: "asMama", ask: "你有包子吗?", askEn: "Do you have baozi?", answer: "我有包子！", ansPy: "Wǒ yǒu bāozi!", tokens: ["我", "有", "包子"], accept: ["我有包子", "有"], confirm: "对，你有包子！", confirmEn: "Right — you have baozi!" },
      { role: "asMama", ask: "谁有包子?", askEn: "Who has baozi?", answer: "我有包子！", ansPy: "Wǒ yǒu bāozi!", tokens: ["我", "有", "包子"], accept: ["我有包子"], confirm: "对，你有包子！", confirmEn: "You do!" },
    ],
    read: { hz: "妈妈说我有包子", tones: [1, 0, 1, 3, 3, 1, 0], opts: ['Mom says, "I have baozi."', "Mom is hungry.", "Mom goes to the store."], correct: 0 },
    readVariants: [
      { hz: "妈妈有包子", opts: ["Mom has baozi.", "Mom has no baozi.", "Xiao Ming has baozi."], correct: 0 },
      { hz: "小明说他很饿", opts: ['Xiao Ming says he is very hungry.', 'Mom says she is very hungry.', 'Xiao Ming says he is very happy.'], correct: 0 },
      { hz: "小明没有包子", opts: ["Xiao Ming has no baozi.", "Xiao Ming has baozi.", "Mom has no baozi."], correct: 0 },
    ],
    write: "妈妈有包子",
    newWords: [{ hz: "说", tones: [1], en: "say" }, { hz: "有", tones: [3], en: "have" }],
  },
  {
    key: "s8", sentence: { hz: "小明很高兴！", py: "Xiǎo Míng hěn gāoxìng!", en: "Xiao Ming is very happy!", emoji: "😄" },
    frame: "小明{}", frameEn: "Xiao Ming is {}", neg: "小明不难过",
    circle: { pool: ["happy", "sad", "hungry"], types: ["yesno", "either", "who"], yesno: { hz: "小明高兴吗?", en: "Is Xiao Ming happy?" }, yesnoAsked: "happy", either: { hz: "小明高兴还是难过?", en: "Happy or sad?" }, eitherOptions: ["happy", "sad"], who: { hz: "小明怎么样?", en: "How is Xiao Ming?" }, novelty: false },
    youAre: "Xiao Ming 👦🏽",
    tri: [
      { first: true, role: "self", ask: "你高兴吗?", askEn: "Are you happy?", answer: "我很高兴！", ansPy: "Wǒ hěn gāoxìng!", tokens: ["我", "很", "高兴"], accept: ["我很高兴", "高兴", "我高兴"], confirm: "对，你很高兴！", confirmEn: "Right — you're happy!" },
      { role: "self", ask: "你难过吗?", askEn: "Are you sad?", answer: "不，我很高兴！", ansPy: "Bù, wǒ hěn gāoxìng!", tokens: ["不", "我", "很", "高兴"], accept: ["不我很高兴", "我很高兴", "我不难过"], confirm: "对，你不难过，你很高兴！", confirmEn: "Right — not sad, happy!" },
      { role: "self", ask: "你怎么样?", askEn: "How are you?", answer: "我很高兴！", ansPy: "Wǒ hěn gāoxìng!", tokens: ["我", "很", "高兴"], accept: ["我很高兴"], confirm: "对，你很高兴！", confirmEn: "You're happy!" },
    ],
    read: { hz: "小明很高兴", tones: [3, 2, 3, 1, 4], opts: ["Xiao Ming is very happy.", "Xiao Ming is very sad.", "Xiao Ming is very hungry."], correct: 0 },
    readVariants: [
      { hz: "他不难过", opts: ["He is not sad.", "He is very sad.", "He is not happy."], correct: 0 },
      { hz: "小明吃包子", opts: ["Xiao Ming eats baozi.", "Xiao Ming eats an apple.", "Mom eats baozi."], correct: 0 },
      { hz: "我很高兴", opts: ["I am very happy.", "You are very happy.", "I am very sad."], correct: 0 },
    ],
    write: "小明很高兴",
    newWords: [],
  },
];

const TRI_PAL_EXTRAS = ["小明", "妈妈", "包子", "苹果", "商店", "很", "饿", "高兴", "难过", "想", "吃", "去", "有", "没有", "是", "不", "对", "说"];
const PUNCT = ["，", "。", "！", "\u201C", "\u201D"];

/* question-word toolbox shown before + during Triangle */
const TRI_HELP = [
  { hz: "你", en: "you", emoji: "👉" },
  { hz: "我", en: "I / me", emoji: "🙋" },
  { hz: "谁", en: "who?", emoji: "🕵️" },
  { hz: "不", en: "no / not", emoji: "🙅" },
  { hz: "吗", en: "…? (makes it a question)", emoji: "❓" },
];

/* humor pools */
const SILLY_READS = ["Bobo ate all the baozi. ALL of them.", "A panda is driving the school bus.", "This is a potato.", "Mom is secretly a ninja.", "The baozi escaped out the window.", "Bobo is stuck in a tree again."];
const QUIPS = ["波波 approves. 🐼", "Bobo just did a mental backflip.", "Somewhere, a baozi is cheering.", "Faster than a panda chasing snacks!", "Teacher-level answer. 🌟", "Bobo wants your autograph."];
const LESSON_BADGES = ["Name Tag Ninja 🥷", "Hunger Detector 🚨", "Baozi Dreamer 🥟💭", "Store Navigator 🧭", "Bad News Survivor 😱", "Sad Violin Soloist 🎻", "Mom's Best Helper 🦸", "Happy Ending Hero 🏆"];

/* ---------- class-code gate (edit CLASS_CODES to change the password) ---------- */
const CLASS_CODES = ["baozi", "包子"];
function GateScreen({ onUnlock }) {
  const [val, setVal] = useState("");
  const [tries, setTries] = useState(0);
  const [shake, setShake] = useState(false);
  const lines = ["Hmm... that's not it. Ask your teacher! 🐼", "Nope! 波波 guards this door well. 🚪", "Not quite — the code is something delicious...", "波波 says: try again! 💪"];
  const submit = () => {
    if (CLASS_CODES.includes(val.trim().toLowerCase())) { chimeYay(); onUnlock(); }
    else { chimeOops(); setTries((x) => x + 1); setShake(true); setTimeout(() => setShake(false), 450); setVal(""); }
  };
  return (
    <div style={{ minHeight: "70vh", display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
      <Card style={{ padding: 34, textAlign: "center", maxWidth: 420, width: "100%", animation: shake ? "gateshake .4s ease" : "fadeUp .4s ease both" }}>
        <div style={{ fontSize: 70 }}>🐼</div>
        <div style={{ fontFamily: "'Bricolage Grotesque',sans-serif", fontWeight: 700, fontSize: 24, color: "#2c2620", marginTop: 6 }}>Story Lab</div>
        <div style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 14, color: "#7a6f5e", marginTop: 10 }}>What's the class code? Your teacher has it!</div>
        <input value={val} onChange={(e) => setVal(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") submit(); }} autoFocus placeholder="class code" style={{ marginTop: 16, width: "100%", maxWidth: 260, padding: "13px 18px", borderRadius: 999, border: "2px solid #e7dcc8", fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 17, textAlign: "center", outline: "none", color: "#3a3329", background: "#fffdf8" }} />
        <div style={{ marginTop: 14 }}><Btn onClick={submit}>Let me in! 🚪</Btn></div>
        {tries > 0 && <div style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 13, color: "#b05c1f", marginTop: 12 }}>{lines[(tries - 1) % lines.length]}</div>}
      </Card>
    </div>
  );
}

/* ---------- persistent progress (survives across sessions) ---------- */
const PKEY = "storylab-progress-v1";
async function loadProgress() { try { const r = await window.storage.get(PKEY); return r && r.value ? JSON.parse(r.value) : null; } catch (e) { return null; } }
async function saveProgress(p) { try { await window.storage.set(PKEY, JSON.stringify(p)); } catch (e) { /* storage unavailable — session-only mode */ } }

const MIN_REPS = 10, MASTERY_STREAK = 4, MAX_REPS = 42, FAST_MS = 2200;
const READ_STREAK = 10, READ_FAST_MS = 2800;
const TRI_MIN = 12, TRI_STREAK = 5, TRI_MAX = 60;

const CHARTONE = { 这: 4, 是: 4, 小: 3, 明: 2, 妈: 1, 不: 4, 你: 3, 我: 3, 他: 1, 对: 4, 谁: 2, 吗: 0, 还: 2, 很: 3, 饿: 4, 高: 1, 兴: 4, 难: 2, 过: 4, 想: 3, 吃: 1, 包: 1, 子: 0, 去: 4, 商: 1, 店: 4, 没: 2, 有: 3, 苹: 2, 果: 3, 学: 2, 校: 4, 哪: 3, 儿: 0, 什: 2, 么: 0, 怎: 3, 样: 4, 说: 1, 家: 1, 可: 3, 乐: 4, 功: 1, 夫: 0, 披: 1, 萨: 4, 咖: 1, 啡: 1, 巧: 3, 克: 4, 力: 4, 和: 2, 因: 1, 为: 4, 然: 2, 后: 4, 波: 1, 哎: 1, 哇: 1 };

/* ================================================================== */
/*  AUDIO                                                              */
/* ================================================================== */
function pickZhVoice() { try { return (window.speechSynthesis.getVoices() || []).find((v) => /zh|chinese|mandarin/i.test((v.lang || "") + (v.name || ""))); } catch (e) { return null; } }
function speak(text, rate, onend) {
  try {
    const s = window.speechSynthesis; if (!s) { onend && setTimeout(onend, 500); return; }
    s.cancel();
    const u = new SpeechSynthesisUtterance(String(text).replace(/[^\u4e00-\u9fff\uff01\uff1f\u3002\uff0c0-9]/g, ""));
    u.lang = "zh-CN"; u.rate = rate || 0.85; const v = pickZhVoice(); if (v) u.voice = v;
    let f = false; if (onend) { u.onend = () => { if (!f) { f = true; onend(); } }; setTimeout(() => { if (!f) { f = true; onend(); } }, 3200); }
    s.speak(u);
  } catch (e) { onend && onend(); }
}
function speakEn(text) { try { const s = window.speechSynthesis; if (!s) return; s.cancel(); const u = new SpeechSynthesisUtterance(text); u.lang = "en-US"; const v = (s.getVoices() || []).find((x) => /en[-_]/i.test(x.lang)); if (v) u.voice = v; s.speak(u); } catch (e) {} }
let AC;
function ac() { try { if (!AC) AC = new (window.AudioContext || window.webkitAudioContext)(); if (AC.state === "suspended") AC.resume(); return AC; } catch (e) { return null; } }
function blip(fr, s, d, g0) { const c = ac(); if (!c) return; const o = c.createOscillator(), g = c.createGain(); o.type = "sine"; o.frequency.value = fr; o.connect(g); g.connect(c.destination); const t = c.currentTime + s; g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(g0 || 0.16, t + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t + d); o.start(t); o.stop(t + d + 0.02); }
let AUDIO_UNLOCKED = false;
function unlockAudioOnce() {
  if (AUDIO_UNLOCKED) return; AUDIO_UNLOCKED = true;
  try { ac(); } catch (e) {}
  try { const u = new SpeechSynthesisUtterance(" "); u.volume = 0; window.speechSynthesis.speak(u); } catch (e) {}
}
if (typeof window !== "undefined") window.addEventListener("pointerdown", unlockAudioOnce, { once: true, capture: true });
const chimeYay = () => { blip(659.25, 0, 0.12, 0.13); blip(987.77, 0.08, 0.18, 0.13); };
const chimeOops = () => { blip(311.13, 0, 0.2, 0.1); };
const fanfare = () => { [523.25, 659.25, 783.99, 1046.5].forEach((f, i) => blip(f, i * 0.12, 0.32, 0.16)); blip(1318.5, 0.5, 0.55, 0.18); blip(1046.5, 0.5, 0.55, 0.12); };
const tick = () => blip(440, 0, 0.06, 0.06);
const popCue = () => { blip(880, 0, 0.07, 0.13); blip(1174.66, 0.05, 0.08, 0.1); };
const speedNote = (rt) => { const f = Math.max(500, Math.min(1300, 1400 - rt * 1.4)); blip(f, 0, 0.12, 0.14); blip(f * 1.25, 0.09, 0.16, 0.14); };
const victoryTune = () => {
  [523.25, 659.25, 783.99, 1046.5, 1318.5, 1567.98].forEach((f, i) => blip(f, i * 0.13, 0.3, 0.15));
  [1046.5, 1318.5, 1567.98].forEach((f) => blip(f, 0.95, 0.85, 0.13));
  [2093, 1760, 2349].forEach((f, i) => blip(f, 1.5 + i * 0.18, 0.3, 0.08));
  [783.99, 1046.5, 1318.5, 1567.98, 2093].forEach((f, i) => blip(f, 2.2 + i * 0.14, 0.28, 0.13));
  [1318.5, 1567.98, 2093].forEach((f) => blip(f, 3.1, 1.0, 0.12));
};

/* ================================================================== */
/*  HELPERS + UI                                                       */
/* ================================================================== */
function shuffle(a) { const b = [...a]; for (let i = b.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1));[b[i], b[j]] = [b[j], b[i]]; } return b; }
function ent(id) { return E[id] || NOVELTY.find((n) => n.id === id); }
function pick(a) { return a[Math.floor(Math.random() * a.length)]; }
const norm = (s) => String(s).replace(/[^\u4e00-\u9fffa-zA-Z0-9]/g, "");
const frameCn = (cfg, e) => cfg.frame.replace("{}", e.full);
const frameEnS = (cfg, e) => { const s = cfg.frameEn.replace("{}", e.en); return s.charAt(0).toUpperCase() + s.slice(1); };

function ToneLabel({ label, tones, size = 26 }) { const cs = Array.from(label); return <span style={{ fontFamily: "'Noto Sans SC',sans-serif", fontWeight: 700, fontSize: size }}>{cs.map((c, i) => <span key={i} className={tones[i] != null ? "tone" + tones[i] : ""}>{c}</span>)}</span>; }
function Colored({ text, size = 22 }) { return <span style={{ fontFamily: "'Noto Sans SC',sans-serif", fontWeight: 600, fontSize: size }}>{Array.from(String(text)).map((c, i) => { const t = CHARTONE[c]; return <span key={i} className={t != null ? "tone" + t : ""} style={t == null ? { color: "#7a6f5e" } : undefined}>{c}</span>; })}</span>; }
function Bobo({ children, big, face = "🐼" }) { return <div className="flex items-start" style={{ gap: 12 }}><span style={{ fontSize: big ? 50 : 32, animation: "bobble 3.4s ease-in-out infinite", flexShrink: 0 }}>{face}</span><div style={{ background: "#fff", border: "1px solid #efe6d4", borderRadius: 18, padding: "12px 16px", boxShadow: "0 8px 24px -16px rgba(120,90,40,.4)", fontFamily: "Nunito,sans-serif", color: "#3a3329", fontSize: 16, lineHeight: 1.5 }}>{children}</div></div>; }
function Btn({ children, onClick, kind = "primary", disabled, style }) {
  const base = { border: "none", borderRadius: 999, fontFamily: "Nunito,sans-serif", fontWeight: 800, cursor: disabled ? "default" : "pointer", display: "inline-flex", alignItems: "center", gap: 8, padding: "13px 22px", fontSize: 16, opacity: disabled ? 0.45 : 1 };
  const k = { primary: { background: "linear-gradient(180deg,#EE8A4E,#E0742F)", color: "#fff", boxShadow: "0 10px 22px -10px rgba(224,116,47,.7)" }, ghost: { background: "#fff", color: "#5a4f3e", border: "1px solid #e7dcc8" }, soft: { background: "#F3E9D6", color: "#7a5a2e" } };
  return <button className="btnp" onClick={disabled ? undefined : onClick} disabled={disabled} style={{ ...base, ...k[kind], ...style }}>{children}</button>;
}
function Card({ children, style }) { return <div className="fadeUp" style={{ background: "rgba(255,255,255,.8)", backdropFilter: "blur(6px)", border: "1px solid rgba(120,90,40,.10)", borderRadius: 26, boxShadow: "0 18px 44px -26px rgba(90,65,25,.4)", padding: 24, ...style }}>{children}</div>; }
function Confetti({ seed }) {
  const [ps, setPs] = useState([]);
  useEffect(() => { if (!seed) return; const cols = ["#EE8A4E", "#1F9D57", "#2563EB", "#7C3AED", "#DC2626", "#F2B705"]; setPs(Array.from({ length: 54 }, (_, i) => ({ id: seed + "-" + i, left: Math.random() * 100, dx: Math.random() * 240 - 120, rot: Math.random() * 720 - 360, col: cols[i % cols.length], delay: Math.random() * 0.2, dur: 1 + Math.random() * 0.8, w: 6 + Math.random() * 7 }))); const t = setTimeout(() => setPs([]), 2300); return () => clearTimeout(t); }, [seed]);
  if (!ps.length) return null;
  return <div style={{ position: "fixed", inset: 0, pointerEvents: "none", overflow: "hidden", zIndex: 60 }}>{ps.map((p) => <span key={p.id} style={{ position: "absolute", top: "-14px", left: p.left + "%", width: p.w, height: p.w * 0.62, background: p.col, borderRadius: 2, "--dx": p.dx + "px", "--rot": p.rot + "deg", animation: "confettiFall " + p.dur + "s " + p.delay + "s cubic-bezier(.2,.6,.4,1) forwards" }} />)}</div>;
}
function PlayBig({ onClick, size = 88 }) { return <button className="btnp" onClick={onClick} style={{ width: size, height: size, borderRadius: 28, border: "none", background: "linear-gradient(180deg,#EE8A4E,#E0742F)", color: "#fff", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 16px 30px -14px rgba(224,116,47,.7)" }}><Volume2 size={size * 0.43} /></button>; }
const optStyle = (b, bg) => ({ display: "flex", flexDirection: "column", alignItems: "center", gap: 4, padding: "14px 18px", borderRadius: 18, cursor: "pointer", border: "2px solid " + b + "33", background: bg, minWidth: 116 });
function DancingPanda() { return <div style={{ fontSize: 74, display: "inline-block", animation: "dance .7s ease-in-out infinite" }}>🐼</div>; }
function SelfEval({ onPick }) {
  const opts = [[5, "I've got this — that was easy!"], [4, "It's hard, but I've got it."], [3, "I can do this with support."], [2, "I need some more practice."], [1, "I need lots more practice."]];
  return (
    <div className="flex flex-col" style={{ gap: 16 }}>
      <Bobo big>How did that feel? 🐼 Be honest — there's no wrong answer.</Bobo>
      <Card><div className="flex flex-col" style={{ gap: 10 }}>{opts.map(([n, label]) => (
        <button key={n} className="opt btnp" onClick={() => onPick(n)} style={{ display: "flex", alignItems: "center", gap: 12, padding: "13px 16px", borderRadius: 16, cursor: "pointer", border: "1px solid #e7dcc8", background: "#fffdf8", textAlign: "left" }}>
          <span style={{ width: 34, height: 34, borderRadius: 999, background: "linear-gradient(180deg,#F2B705,#E0742F)", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "Nunito,sans-serif", fontWeight: 800, flexShrink: 0 }}>{n}</span>
          <span style={{ fontFamily: "Nunito,sans-serif", fontWeight: 700, color: "#3a3329" }}>{label}</span>
        </button>
      ))}</div></Card>
    </div>
  );
}
function Cheer({ title, sub, onNext, nextLabel }) {
  useEffect(() => { fanfare(); }, []);
  return <Card style={{ textAlign: "center", padding: 36 }}><DancingPanda /><div style={{ fontFamily: "'Bricolage Grotesque',sans-serif", fontWeight: 700, fontSize: 27, color: "#2c2620", marginTop: 6 }}>{title}</div>{sub && <div style={{ fontFamily: "Nunito,sans-serif", color: "#7a6f5e", marginTop: 8, fontSize: 15 }}>{sub}</div>}<div style={{ marginTop: 22 }}><Btn onClick={onNext}>{nextLabel} <ChevronRight size={18} /></Btn></div></Card>;
}

/* ================================================================== */
/*  MEGA CELEBRATION — full-screen lesson-complete blowout             */
/* ================================================================== */
function MegaCelebration({ idx, onDone }) {
  const [ps] = useState(() => {
    const cols = ["#EE8A4E", "#1F9D57", "#2563EB", "#7C3AED", "#DC2626", "#F2B705"];
    return Array.from({ length: 130 }, (_, i) => ({ id: i, left: Math.random() * 100, dx: Math.random() * 320 - 160, rot: Math.random() * 900 - 450, col: cols[i % cols.length], delay: Math.random() * 0.5, dur: 1.3 + Math.random() * 1.2, w: 7 + Math.random() * 9 }));
  });
  useEffect(() => { victoryTune(); const t = setTimeout(onDone, 4600); return () => clearTimeout(t); }, []); // eslint-disable-line
  return (
    <div onClick={onDone} style={{ position: "fixed", inset: 0, zIndex: 100, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", background: "radial-gradient(800px 500px at 50% 40%, rgba(255,247,233,.97), rgba(244,236,220,.97))", animation: "fadeUp .3s ease both" }}>
      <div style={{ position: "absolute", inset: 0, pointerEvents: "none", overflow: "hidden" }}>{ps.map((p) => <span key={p.id} style={{ position: "absolute", top: "-16px", left: p.left + "%", width: p.w, height: p.w * 0.62, background: p.col, borderRadius: 2, "--dx": p.dx + "px", "--rot": p.rot + "deg", animation: "confettiFall " + p.dur + "s " + p.delay + "s cubic-bezier(.2,.6,.4,1) forwards" }} />)}</div>
      <div style={{ textAlign: "center", animation: "popIn .5s cubic-bezier(.2,.7,.3,1.2) both" }}>
        <div style={{ fontSize: 44, animation: "discoswing 2.2s ease-in-out infinite", display: "inline-block", marginBottom: -6 }}>🪩</div>
        <div style={{ position: "relative", height: 150, display: "flex", alignItems: "flex-end", justifyContent: "center", gap: 6 }}>
          {["🎵", "🎶", "🎵", "🎶"].map((n, i) => <span key={i} style={{ position: "absolute", bottom: 60, left: 28 + i * 32 + "%", fontSize: 22, animation: "noteFloat 1.6s " + i * 0.4 + "s ease-out infinite", opacity: 0 }}>{n}</span>)}
          <span style={{ fontSize: 62, display: "inline-block", animation: "backupdance 1.1s ease-in-out infinite", transformOrigin: "50% 90%" }}>🐼</span>
          <span style={{ fontSize: 112, display: "inline-block", animation: "discodance 1.4s ease-in-out infinite", transformOrigin: "50% 60%" }}>🐼</span>
          <span style={{ fontSize: 62, display: "inline-block", animation: "backupdance 1.1s .55s ease-in-out infinite", transformOrigin: "50% 90%" }}>🐼</span>
        </div>
        <div style={{ width: 280, height: 12, margin: "2px auto 0", borderRadius: "50%", background: "radial-gradient(closest-side, rgba(224,116,47,.35), transparent)", animation: "floorpulse .7s ease-in-out infinite alternate" }} />
        <div style={{ fontFamily: "'Bricolage Grotesque',sans-serif", fontWeight: 700, fontSize: 34, color: "#2c2620", marginTop: 8 }}>Lesson {idx + 1} complete!</div>
        <div style={{ marginTop: 12, display: "inline-block", background: "linear-gradient(180deg,#F2B705,#E0742F)", color: "#fff", fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 19, borderRadius: 999, padding: "10px 26px", boxShadow: "0 14px 30px -12px rgba(224,116,47,.7)" }}>
          Badge earned: {LESSON_BADGES[idx] || "Mandarin Star ⭐"}
        </div>
        <div style={{ marginTop: 18, fontFamily: "Nunito,sans-serif", color: "#a99a80", fontWeight: 700, fontSize: 13 }}>tap anywhere to keep going</div>
      </div>
    </div>
  );
}

/* ================================================================== */
/*  LESSON MAP — preview / jump to any sentence & phase                */
/* ================================================================== */
function LessonMap({ rate, currentIdx, completed = [], onJump, onParty, onSong, onClose }) {
  const upNext = SENTENCES.findIndex((_, i) => !completed.includes(i));
  const phases = [["listen", "Listen"], ["circle", "Circle"], ["triangle", "Triangle"], ["match", "Match"], ["read", "Read"], ["write", "Write"], ["dts", "Tell It"]];
  return (
    <div className="flex flex-col" style={{ gap: 14 }}>
      <Bobo big>The whole story, 🗺️ one sentence per lesson. Tap a phase to jump straight there — great for previewing.</Bobo>
      {SENTENCES.map((s, i) => (
        <Card key={s.key} style={{ padding: 16, border: i === currentIdx ? "2px solid #E0742F" : undefined }}>
          <div className="flex items-center" style={{ gap: 12 }}>
            <span style={{ fontSize: 34, flexShrink: 0 }}>{s.sentence.emoji}</span>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="flex items-center" style={{ gap: 8, flexWrap: "wrap" }}>
                <span style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 12, color: "#a99a80" }}>LESSON {i + 1}</span>
                {completed.includes(i) && <span style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 11, color: "#1F9D57", background: "#EAF7EE", border: "1px solid #bfe3c8", borderRadius: 999, padding: "2px 9px" }}>✓ done</span>}
                {i === upNext && <span style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 11, color: "#b05c1f", background: "#FDEBD7", border: "1px solid #f3d6ae", borderRadius: 999, padding: "2px 9px" }}>★ up next</span>}
                <Colored text={s.sentence.hz} size={19} />
                <button className="btnp" onClick={() => speak(s.sentence.hz, rate)} style={{ border: "none", background: "#F3E9D6", borderRadius: 8, padding: "4px 6px", cursor: "pointer" }}><Volume2 size={13} color="#b07a3a" /></button>
              </div>
              <div style={{ fontFamily: "Nunito,sans-serif", color: "#7a6f5e", fontSize: 13, marginTop: 2 }}>{s.sentence.en}</div>
            </div>
          </div>
          <div className="flex" style={{ gap: 6, marginTop: 10, flexWrap: "wrap" }}>
            {phases.map(([k, label]) => (
              <button key={k} className="btnp" onClick={() => onJump(i, k)} style={{ border: "1px solid #e7dcc8", background: "#fffdf8", borderRadius: 999, padding: "6px 13px", cursor: "pointer", fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 12, color: "#5a4f3e" }}>{label}</button>
            ))}
            {onParty && <button className="btnp" onClick={() => onParty(i)} style={{ border: "1px solid #f3d6ae", background: "#FDF3E3", borderRadius: 999, padding: "6px 13px", cursor: "pointer", fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 12, color: "#b05c1f" }}>🎉 Party</button>}
            {onSong && <button className="btnp" onClick={() => onSong(i)} style={{ border: "1px solid #d9c8ef", background: "#F6F0FD", borderRadius: 999, padding: "6px 13px", cursor: "pointer", fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 12, color: "#7C3AED" }}>🎬 Song</button>}
          </div>
        </Card>
      ))}
      <div className="flex justify-center"><Btn kind="ghost" onClick={onClose}>← Back</Btn></div>
    </div>
  );
}

/* spiral helpers */
function matchWordsUpTo(idx) {
  const cur = SENTENCES[idx].newWords || [];
  const prior = [];
  for (let i = 0; i < idx; i++) (SENTENCES[i].newWords || []).forEach((w) => prior.push(w));
  const review = shuffle(prior).slice(0, 3);
  const seen = {}; const out = [];
  [...cur, ...review].forEach((w) => { if (!seen[w.hz]) { seen[w.hz] = 1; out.push(w); } });
  return out.length ? out : (prior.length ? shuffle(prior).slice(0, 3) : cur);
}
function readItemsUpTo(idx) {
  const tonesOf = (hz) => Array.from(hz).map((c) => (CHARTONE[c] != null ? CHARTONE[c] : 0));
  const out = [];
  SENTENCES.slice(0, idx + 1).forEach((s, i) => {
    out.push({ ...s.read, _k: "m" + i });
    (s.readVariants || []).forEach((v, j) => out.push({ ...v, tones: v.tones || tonesOf(v.hz), _k: "v" + i + "-" + j }));
  });
  return out;
}

/* ================================================================== */
/*  CALIBRATION                                                        */
/* ================================================================== */
function Calibrate({ onDone }) {
  const [armed, setArmed] = useState(false), [shown, setShown] = useState(false), [trial, setTrial] = useState(0), [times, setTimes] = useState([]);
  const tRef = useRef(0), shownRef = useRef(false), TRIALS = 4;
  const arm = () => { tick(); setArmed(true); setShown(false); shownRef.current = false; const w = 700 + Math.random() * 1500; setTimeout(() => { if (!shownRef.current) { tRef.current = performance.now(); shownRef.current = true; setShown(true); popCue(); } }, w); };
  const hit = () => { if (!armed) { arm(); return; } if (!shown) { chimeOops(); setArmed(false); shownRef.current = true; return; } const rt = performance.now() - tRef.current; speedNote(rt); const nt = [...times, rt]; setTimes(nt); setArmed(false); setShown(false); if (trial + 1 >= TRIALS) { fanfare(); const s = [...nt].sort((a, b) => a - b); onDone(Math.min(600, Math.max(150, s[Math.floor(s.length / 2)]))); } else setTrial(trial + 1); };
  return (
    <div className="flex flex-col" style={{ gap: 18 }}>
      <Bobo big>你好! 我是波波. 🐼 First, a 4-tap speed warm-up so I learn <i>your</i> tapping speed. Tap the circle the instant it turns orange.</Bobo>
      <Card style={{ textAlign: "center", padding: 30 }}>
        <div style={{ fontFamily: "Nunito,sans-serif", color: "#a99a80", fontWeight: 800, fontSize: 13, letterSpacing: 1 }}>{trial + 1} / {TRIALS}</div>
        <div onClick={hit} style={{ margin: "22px auto", width: 150, height: 150, borderRadius: 999, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", transition: "background .08s, transform .08s", background: shown ? "linear-gradient(180deg,#EE8A4E,#E0742F)" : armed ? "#ece2cf" : "#F3E9D6", transform: shown ? "scale(1.05)" : "scale(1)", userSelect: "none" }}><span style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, color: shown ? "#fff" : "#b8a98e", fontSize: 18 }}>{shown ? "TAP!" : armed ? "wait…" : "Tap to start"}</span></div>
        <div style={{ fontFamily: "Nunito,sans-serif", color: "#9a8f7e", fontSize: 14 }}>{times.length ? "Last: " + Math.round(times[times.length - 1]) + " ms" : "Tap the big circle to begin"}</div>
        <div style={{ marginTop: 16 }}><Btn kind="ghost" onClick={() => onDone(330)} style={{ fontSize: 13, padding: "8px 14px" }}>Skip warm-up</Btn></div>
      </Card>
    </div>
  );
}

/* ================================================================== */
/*  1 — LISTEN                                                         */
/* ================================================================== */
function ListenSub({ cfg, rate, onUnderstand }) {
  const [plays, setPlays] = useState(0); const ready = plays >= 3;
  const line = useMemo(() => pick([
    <>Listen first. 🎧 Hear it a few times and picture what it means.</>,
    <>Ears on! 🎧 No reading yet — your ears go first. Your eyes get a turn later.</>,
    <>🎧 Close your eyes if it helps. (Not while walking.)</>,
    <>Listen up! 🎧 Bobo believes in you. Bobo also believes in snacks.</>,
    <>🎧 Play it, picture it, feel it. That's how pandas learn. Probably.</>,
  ]), [cfg.key]);
  useEffect(() => { setPlays(0); const t = setTimeout(() => { speak(cfg.sentence.hz, rate); setPlays(1); }, 350); return () => clearTimeout(t); }, [cfg.key]);
  return (
    <div className="flex flex-col" style={{ gap: 18 }}>
      <Bobo>{line}</Bobo>
      <Card style={{ textAlign: "center", padding: 30 }}>
        <div style={{ fontSize: 84, lineHeight: 1 }}>{cfg.sentence.emoji}</div>
        <div style={{ fontFamily: "Nunito,sans-serif", fontSize: 21, color: "#3a3329", fontWeight: 700, marginTop: 14 }}>{cfg.sentence.en}</div>
        <div style={{ margin: "22px auto 8px", display: "inline-block" }}><PlayBig onClick={() => { speak(cfg.sentence.hz, rate); setPlays((p) => p + 1); }} /></div>
        <div style={{ fontFamily: "Nunito,sans-serif", color: "#a99a80", fontWeight: 800, fontSize: 14 }}>{ready ? "Heard it " + plays + "× — got it?" : "listen · " + plays + "/3"}</div>
        <div style={{ marginTop: 20 }}><Btn onClick={() => { fanfare(); onUnderstand(); }} disabled={!ready} style={{ fontSize: 18, padding: "15px 28px", animation: ready ? "popIn .4s ease" : "none" }}>I understand! <Sparkles size={18} fill="#fff" /></Btn></div>
      </Card>
    </div>
  );
}

/* ================================================================== */
/*  2 — CIRCLE                                                         */
/* ================================================================== */
function makeQuestion(cfg, prev) {
  const c = cfg.circle, types = c.types || ["yesno", "either", "who"];
  let type = pick(types);
  if (prev && prev.type === type && types.length > 1 && Math.random() < 0.5) type = pick(types);
  const useNov = c.novelty && type === "yesno" && Math.random() < 0.3;
  if (type === "yesno") return { type, useNov, q: c.yesno, shown: useNov ? pick(NOVELTY) : ent(pick(c.pool)), askedId: c.yesnoAsked, invert: !!c.invert };
  if (type === "either") { const o = c.eitherOptions; return { type, q: c.either, shown: ent(pick(o)), options: o }; }
  const o = c.whoOptions || c.pool; return { type, q: c.who, shown: ent(pick(o)), options: o };
}
function CircleSub({ cfg, rate, baseline, onComplete, fireConfetti }) {
  const [q, setQ] = useState(null), [reps, setReps] = useState(0), [streak, setStreak] = useState(0), [verify, setVerify] = useState(null), [mode, setMode] = useState("intro"), [rem, setRem] = useState(null), [showEn, setShowEn] = useState(false), [lastFast, setLastFast] = useState(null);
  const errs = useRef({}), tShow = useRef(0), tAudio = useRef(0), prevQ = useRef(null);
  useEffect(() => { setMode("intro"); setReps(0); setStreak(0); setVerify(null); errs.current = {}; prevQ.current = null; }, [cfg.key]);
  function present(question) { setQ(question); setShowEn(false); setMode("q"); setVerify(null); tShow.current = performance.now(); tAudio.current = 0; speak(question.q.hz, rate, () => { tAudio.current = performance.now(); }); }
  function nextQ() { const nq = makeQuestion(cfg, prevQ.current); prevQ.current = nq; present(nq); }
  function classify(c) { const now = performance.now(); const base = tAudio.current || (tShow.current + 1400); let rt = now - base; if (rt < 0) rt = 150; const fast = Math.max(0, rt - baseline) < FAST_MS; setLastFast(fast); return c ? (fast ? "FC" : "SC") : (fast ? "FI" : "SI"); }

  function answer(correct) {
    if (mode !== "q") return;
    const sig = classify(correct), shown = q.shown, isYN = q.type === "yesno", isTarget = shown.id === q.askedId;
    if (sig === "FI") { chimeOops(); setStreak(0); setVerify({ slip: true }); setTimeout(() => { setVerify(null); setMode("q"); tShow.current = performance.now(); tAudio.current = performance.now(); }, 1050); return; }
    let cn, en;
    if (isYN && q.invert) { cn = (correct ? "对，" : "不对，") + frameCn(cfg, shown) + "。"; en = (correct ? "Right — " : "Not quite — ") + frameEnS(cfg, shown) + "."; }
    else if (isYN && !isTarget) { cn = (correct ? "对，" : "不对，") + frameCn(cfg, shown) + "。" + (cfg.neg ? cfg.neg + "，" + frameCn(cfg, shown) + "。" : frameCn(cfg, shown) + "。"); en = (correct ? "Right — " : "Not quite — ") + frameEnS(cfg, shown) + "."; }
    else { cn = (correct ? "对！" : "不对，") + frameCn(cfg, shown) + "。"; en = (correct ? "Yes — " : "Not quite — ") + frameEnS(cfg, shown) + "."; }
    if (correct && sig === "FC" && Math.random() < 0.35) en += "  " + pick(QUIPS);
    const newReps = reps + 1, newStreak = sig === "FC" ? streak + 1 : 0; setReps(newReps); setStreak(newStreak);
    if (correct) chimeYay(); else chimeOops();
    let action = "next";
    if (sig === "SI") { errs.current[shown.id] = (errs.current[shown.id] || 0) + 1; if (errs.current[shown.id] >= 2) action = "rem"; }
    if (action === "next" && newReps >= MIN_REPS && newStreak >= MASTERY_STREAK) action = "ready";
    if (action === "next" && newReps >= MAX_REPS) action = "ready";
    setVerify({ ok: correct, sig, cn, en, action, shown }); setMode("verify"); speak(cn, rate);
  }
  function onNext() { const a = verify.action, shown = verify.shown; setVerify(null); if (a === "rem") startRem(shown); else if (a === "ready") becomeReady(); else nextQ(); }
  function startRem(e) { setRem(e); setMode("rem"); speak(frameCn(cfg, e), rate, () => speak(frameCn(cfg, e), rate)); }
  function endRem() { if (rem) errs.current[rem.id] = 0; setRem(null); nextQ(); }
  function becomeReady() { releaseMicSoon(0); setMode("ready"); fireConfetti(); fanfare(); }

  if (mode === "intro") { const sw = STRUCT_WORDS[cfg.key] || []; return (
    <div className="flex flex-col" style={{ gap: 16 }}>
      <Bobo>好! Let's circle this one. 🐼 Tap each word to hear it. {cfg.key === "s1" && <>And remember: <b>小明 is the boy's name</b> — like "Mike" — it doesn't mean "boy"!</>}</Bobo>
      <Card style={{ padding: 24 }}>
        <div className="flex justify-center" style={{ gap: 14, flexWrap: "wrap" }}>{(cfg.circle.pool).map((id) => { const e = ent(id); return (
          <button key={id} className="btnp" onClick={() => speak(e.label, rate)} style={{ border: "1px solid #ece2cf", background: "#fffdf8", borderRadius: 18, padding: "14px 20px", cursor: "pointer", textAlign: "center", maxWidth: 170 }}>
            <div style={{ fontSize: 50 }}>{e.emoji}</div>
            <div className="flex items-center justify-center" style={{ gap: 6, marginTop: 4 }}><span style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, color: "#3a3329", fontSize: 16 }}>{e.en}</span><Volume2 size={14} color="#c2a878" /></div>
            {e.note && <div style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 11, color: "#b07a3a", marginTop: 4, lineHeight: 1.3 }}>{e.note}</div>}
          </button>
        ); })}</div>
        {sw.length > 0 && (
          <div style={{ textAlign: "center", marginTop: 18 }}>
            <div style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 11, color: "#a99a80", letterSpacing: 1, textTransform: "uppercase", marginBottom: 8 }}>the glue words</div>
            <div className="flex justify-center" style={{ gap: 10, flexWrap: "wrap" }}>
              {sw.map((w) => (
                <button key={w.hz} className="btnp" onClick={() => speak(w.hz, rate)} style={{ border: "1.5px dashed #e0d3b8", background: "#FDFAF2", borderRadius: 16, padding: "10px 16px", cursor: "pointer", textAlign: "center", minWidth: 92 }}>
                  <div style={{ fontSize: 26 }}>{w.emoji}</div>
                  <div style={{ marginTop: 3 }}><Colored text={w.hz} size={20} /></div>
                  <div className="flex items-center justify-center" style={{ gap: 4, marginTop: 2 }}><span style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 12, color: "#5a4f3e" }}>{w.en}</span><Volume2 size={11} color="#c2a878" /></div>
                </button>
              ))}
            </div>
          </div>
        )}
        <div className="flex justify-center" style={{ marginTop: 22 }}><Btn onClick={() => nextQ()}>Start practicing <ChevronRight size={18} /></Btn></div>
      </Card>
    </div>
  ); }
  if (mode === "rem" && rem) return <div className="flex flex-col" style={{ gap: 16 }}><Bobo>No rush — warm up this one. 💪</Bobo><Card style={{ textAlign: "center", padding: 34, border: "2px solid #F2B705" }}><div style={{ fontSize: 80 }}>{rem.emoji}</div><div style={{ fontFamily: "Nunito,sans-serif", color: "#3a3329", marginTop: 8, fontWeight: 800, fontSize: 18 }}>{rem.en}</div><div style={{ display: "inline-block", marginTop: 14 }}><button className="btnp" onClick={() => speak(frameCn(cfg, rem), rate)} style={{ width: 60, height: 60, borderRadius: 18, border: "none", background: "#F3E9D6", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}><Volume2 size={26} color="#b07a3a" /></button></div><div style={{ marginTop: 14 }}><Btn onClick={endRem}>Got it! <Check size={18} /></Btn></div></Card></div>;
  if (mode === "ready") return <div className="flex flex-col" style={{ gap: 16 }}><Bobo big>You've got it! 🎉 Fast <i>and</i> right. Now flip it around.</Bobo><Card style={{ textAlign: "center", padding: 30 }}><div style={{ fontSize: 56 }}>{cfg.sentence.emoji}</div><div style={{ marginTop: 10, fontFamily: "Nunito,sans-serif", color: "#7a6f5e" }}>Heard it <b>{reps}</b> times.</div><div className="flex items-center justify-center" style={{ gap: 10, marginTop: 20, flexWrap: "wrap" }}><Btn onClick={onComplete}>Next: speak it → <ChevronRight size={18} /></Btn><Btn kind="ghost" onClick={() => { setMode("q"); setStreak(0); nextQ(); }}>Keep practicing</Btn></div></Card></div>;

  const shown = q && q.shown;
  return (
    <div className="flex flex-col" style={{ gap: 14 }}>
      <div className="flex items-center justify-between" style={{ fontFamily: "Nunito,sans-serif" }}>
        <div className="flex items-center" style={{ gap: 6 }}>{Array.from({ length: MASTERY_STREAK }).map((_, i) => <span key={i} style={{ width: 11, height: 11, borderRadius: 999, background: i < streak ? "linear-gradient(180deg,#F2B705,#E0742F)" : "#e7dcc8", transition: "background .2s" }} />)}<span style={{ marginLeft: 8, fontSize: 13, color: "#a99a80", fontWeight: 800 }}>in a row</span></div>
        <div className="flex items-center" style={{ gap: 10 }}>{lastFast != null && <span style={{ display: "inline-flex", alignItems: "center", gap: 3, fontSize: 13, fontWeight: 800, color: lastFast ? "#E0742F" : "#b8a98e" }}><Zap size={13} fill={lastFast ? "#E0742F" : "none"} />{lastFast ? "fast" : "—"}</span>}<span style={{ fontSize: 13, color: "#a99a80", fontWeight: 800 }}>{reps} done</span></div>
      </div>
      <Card style={{ textAlign: "center", padding: 26 }}>
        <div style={{ fontSize: 90, lineHeight: 1 }}>{shown && shown.emoji}</div>
        <div className="flex flex-col items-center" style={{ gap: 8, marginTop: 14 }}>
          <div style={{ display: "inline-block" }}><PlayBig onClick={() => q && speak(q.q.hz, rate)} size={64} /></div>
          <button onClick={() => setShowEn(!showEn)} style={{ background: "none", border: "none", cursor: "pointer", color: "#c2b49a", fontFamily: "Nunito,sans-serif", fontSize: 13, display: "inline-flex", alignItems: "center", gap: 4 }}><Languages size={13} /> {showEn ? "hide English" : "show English"}</button>
          {showEn && <div className="fadeUp" style={{ fontFamily: "Nunito,sans-serif", color: "#9a8f7e", fontSize: 16 }}>{q && q.q.en}</div>}
        </div>
        {mode === "q" && q && q.type === "yesno" && <div className="flex justify-center" style={{ gap: 12, marginTop: 20 }}>
          <button className="opt btnp" onClick={() => answer(q.invert ? shown.id !== q.askedId : shown.id === q.askedId)} style={optStyle("#1F9D57", "#eafaf0")}><Check size={24} color="#1F9D57" /><span style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 16, color: "#1F9D57" }}>YES · 对</span></button>
          <button className="opt btnp" onClick={() => answer(q.invert ? shown.id === q.askedId : shown.id !== q.askedId)} style={optStyle("#DC2626", "#fdeaea")}><X size={24} color="#DC2626" /><span style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 16, color: "#DC2626" }}>NO · 不对</span></button>
        </div>}
        {mode === "q" && q && (q.type === "either" || q.type === "who") && <div className="flex flex-wrap justify-center" style={{ gap: 12, marginTop: 20 }}>{q.options.map((oid) => { const o = ent(oid); return <button key={oid} className="opt btnp" onClick={() => answer(oid === shown.id)} style={optStyle("#E0742F", "#fff7ef")}><span style={{ fontSize: 34 }}>{o.emoji}</span><ToneLabel label={o.label} tones={o.tones} size={22} /><span style={{ fontFamily: "Nunito,sans-serif", fontSize: 12, color: "#a99a80", fontWeight: 700 }}>{o.en}</span></button>; })}</div>}
        {verify && verify.slip && <div className="fadeUp" style={{ marginTop: 20, padding: "12px 16px", borderRadius: 16, background: "#fff7e6", border: "1px solid #f0d98a", fontFamily: "Nunito,sans-serif", fontWeight: 800, color: "#b08a2e" }}>⚡ Quick tap — look again!</div>}
        {verify && !verify.slip && (
          <div className="fadeUp" style={{ marginTop: 20, padding: "16px", borderRadius: 16, background: verify.ok ? "#eafaf0" : "#fdeeee", border: "1px solid " + (verify.ok ? "#bfe6cd" : "#f3c9c9") }}>
            <div style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 15, color: verify.ok ? "#1F9D57" : "#c0524a" }}>{verify.ok ? "✓ " : ""}{verify.en}</div>
            <div style={{ marginTop: 8 }}><Colored text={verify.cn} size={22} /></div>
            <div className="flex items-center justify-center" style={{ gap: 10, marginTop: 14, flexWrap: "wrap" }}><Btn kind="soft" onClick={() => speak(verify.cn, rate)}><Volume2 size={16} /> Hear again</Btn><Btn onClick={onNext}>Next <ChevronRight size={18} /></Btn></div>
          </div>
        )}
      </Card>
    </div>
  );
}

/* ================================================================== */
/*  3 — TRIANGLE                                                       */
/* ================================================================== */
function triChips(tokens) { const base = Array.from(new Set([...tokens, "你", "我"])); const ex = TRI_PAL_EXTRAS.filter((x) => !base.includes(x)); return shuffle(Array.from(new Set([...base, ...shuffle(ex).slice(0, 3)]))).concat(PUNCT.slice(0, 3)); }
function TriangleSub({ cfg, rate, onComplete, fireConfetti }) {
  const templates = cfg.tri;
  const [p, setP] = useState(null), [count, setCount] = useState(0), [streak, setStreak] = useState(0), [view, setView] = useState("pronouns"), [showEn, setShowEn] = useState(false), [building, setBuilding] = useState(false), [built, setBuilt] = useState([]), [resp, setResp] = useState(null), [wrong, setWrong] = useState(0), [audioURL, setAudioURL] = useState(null), [micErr, setMicErr] = useState(false);
  const servedFirst = useRef(false), order = useRef([]), ptr = useRef(0), countedRef = useRef(false), mediaRef = useRef(null), chunksRef = useRef([]);
  const chips = useMemo(() => (p ? triChips(p.tokens) : []), [count, view, cfg.key]); // eslint-disable-line
  function nextTemplate() {
    if (!servedFirst.current) { servedFirst.current = true; return templates.find((t) => t.first) || templates[0]; }
    const rest = templates.filter((t) => !t.first);
    if (!rest.length) return templates[0];
    if (ptr.current >= order.current.length) { order.current = shuffle(rest); ptr.current = 0; }
    return order.current[ptr.current++];
  }
  useEffect(() => { servedFirst.current = false; order.current = []; ptr.current = 0; setView("pronouns"); setCount(0); setStreak(0); setP(null); }, [cfg.key]);
  useEffect(() => () => releaseMicSoon(0), []);
  function begin() {
    // one-time mic check at phase start: the permission prompt lands here, so Record is always instant
    getMic().then(() => setMicErr(false)).catch(() => setMicErr(true));
    const f = nextTemplate(); setP(f); setView("ask"); countedRef.current = false; setTimeout(() => speak(f.ask, rate), 250);
  }
  const tally = (ok) => { if (countedRef.current) return; countedRef.current = true; setCount((c) => c + 1); setStreak((s) => (ok ? s + 1 : 0)); };
  const goNext = () => { countedRef.current = false; setBuilding(false); setBuilt([]); setResp(null); setWrong(0); setAudioURL(null); setShowEn(false); const nt = nextTemplate(); setP(nt); setView("ask"); setTimeout(() => speak(nt.ask, rate), 250); };
  async function startRec() {
    try {
      const stream = await getMic();
      const mime = (window.MediaRecorder && MediaRecorder.isTypeSupported && (MediaRecorder.isTypeSupported("audio/webm") ? "audio/webm" : MediaRecorder.isTypeSupported("audio/mp4") ? "audio/mp4" : "")) || "";
      const mr = mime ? new MediaRecorder(stream, { mimeType: mime }) : new MediaRecorder(stream); chunksRef.current = [];
      mr.ondataavailable = (e) => { if (e.data.size) chunksRef.current.push(e.data); };
      mr.onstop = () => { setAudioURL(URL.createObjectURL(new Blob(chunksRef.current, { type: mr.mimeType || "audio/mp4" }))); releaseMicSoon(90000); };
      mediaRef.current = mr; mr.start(); setMicErr(false); setView("recording");
    } catch (e) {
      // device may be briefly busy on Windows — release everything and retry once
      try { releaseMicSoon(0); } catch (e2) {}
      try {
        await new Promise((r) => setTimeout(r, 350));
        const stream = await getMic();
        const mime2 = (window.MediaRecorder && MediaRecorder.isTypeSupported && (MediaRecorder.isTypeSupported("audio/webm") ? "audio/webm" : MediaRecorder.isTypeSupported("audio/mp4") ? "audio/mp4" : "")) || "";
        const mr = mime2 ? new MediaRecorder(stream, { mimeType: mime2 }) : new MediaRecorder(stream); chunksRef.current = [];
        mr.ondataavailable = (ev) => { if (ev.data.size) chunksRef.current.push(ev.data); };
        mr.onstop = () => { setAudioURL(URL.createObjectURL(new Blob(chunksRef.current, { type: mr.mimeType || "audio/mp4" }))); releaseMicSoon(90000); };
        mediaRef.current = mr; mr.start(); setMicErr(false); setView("recording");
      } catch (e3) { setMicErr(true); setBuilding(true); }
    }
  }
  function stopRec() { try { mediaRef.current && mediaRef.current.stop(); } catch (e) {} reveal(true); }
  function reveal(asCorrect) { tally(asCorrect); if (asCorrect) { chimeYay(); fireConfetti(); } setResp({ recast: p.confirm, recast_en: p.confirmEn, model: p.answer, model_py: p.ansPy }); setView("result"); setTimeout(() => speak(p.confirm, rate), 300); }
  function showMe() { tally(false); setResp({ recast: p.confirm, recast_en: p.confirmEn, model: p.answer, model_py: p.ansPy }); setView("result"); setTimeout(() => speak(p.confirm, rate), 200); }
  function checkBuild() { if (p.accept.includes(norm(built.join("")))) reveal(true); else { chimeOops(); setWrong((w) => w + 1); } }
  const addWord = (c) => { speak(c, rate); setBuilt((b) => [...b, c]); };

  if (!p && view !== "pronouns") return null;
  const roleBadge = (role) => {
    if (role === "mama") return <>🐼→👩🏽 I'm <b>Mom</b> now</>;
    if (role === "asMama") return <>You are <b>Mom</b> 👩🏽 now</>;
    if (role === "narrator") return <>🐼 asks about the <b>store</b> 🏪</>;
    return <>🐼 asks <b>you</b> 👦🏽</>;
  };
  const roleEn = (role) => role === "mama" ? "I'm Mom now. You are Xiao Ming." : role === "asMama" ? "You are Mom now." : role === "narrator" ? "Answer about the store." : "I'm asking you. You are Xiao Ming.";

  if (view === "pronouns") return (
    <div className="flex flex-col" style={{ gap: 16 }}>
      <Bobo big>Now <b>YOU</b> answer. 🎭 For this one, <b>you are {cfg.youAre}</b>. First, meet your five tiny power words. The last one, <b>吗</b>, is magic — stick it on the end of anything and <i>BOOM</i>, it's a question. 🪄</Bobo>
      <Card style={{ padding: 24 }}>
        <div style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, color: "#9a8f7e", fontSize: 12, letterSpacing: 1, textTransform: "uppercase", textAlign: "center", marginBottom: 14 }}>five little words — tap each to hear it</div>
        <div className="flex justify-center" style={{ gap: 12, flexWrap: "wrap" }}>
          {TRI_HELP.map((w) => (
            <button key={w.hz} className="btnp" onClick={() => speak(w.hz, rate)} style={{ border: "1px solid #ece2cf", background: "#fffdf8", borderRadius: 18, padding: "14px 16px", cursor: "pointer", textAlign: "center", minWidth: 104 }}>
              <div style={{ fontSize: 34 }}>{w.emoji}</div>
              <div style={{ marginTop: 6 }}><Colored text={w.hz} size={28} /></div>
              <div style={{ fontFamily: "Nunito,sans-serif", color: "#3a3329", fontWeight: 800, marginTop: 2, fontSize: 13 }}>{w.en}</div>
            </button>
          ))}
        </div>
        <div className="flex justify-center" style={{ marginTop: 22 }}><Btn onClick={begin}>I'm ready! <ChevronRight size={18} /></Btn></div>
      </Card>
    </div>
  );

  const enough = count >= TRI_MIN && streak >= TRI_STREAK;
  const pic = p.role === "mama" ? "👩🏽" : p.role === "asMama" ? "👩🏽" : p.role === "narrator" ? "🏪" : "👦🏽";
  return (
    <div className="flex flex-col" style={{ gap: 14 }}>
      <Bobo>You are <b>{cfg.youAre}</b> — answer out loud in a <b>whole sentence</b>.</Bobo>
      <div className="flex items-center justify-between" style={{ fontFamily: "Nunito,sans-serif" }}>
        <div className="flex items-center" style={{ gap: 6 }}>{Array.from({ length: TRI_STREAK }).map((_, i) => <span key={i} style={{ width: 11, height: 11, borderRadius: 999, background: i < streak ? "linear-gradient(180deg,#F2B705,#E0742F)" : "#e7dcc8" }} />)}<span style={{ marginLeft: 8, fontSize: 13, color: "#a99a80", fontWeight: 800 }}>in a row</span></div>
        <span style={{ fontSize: 13, color: "#a99a80", fontWeight: 800 }}>{count} / {TRI_MIN}</span>
      </div>
      <div className="flex justify-center" style={{ gap: 6, flexWrap: "wrap" }}>
        {TRI_HELP.map((w) => (
          <button key={w.hz} className="btnp" onClick={() => speak(w.hz, rate)} title={w.en} style={{ border: "1px solid #ece2cf", background: "#fffdf8", borderRadius: 999, padding: "5px 11px", cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 5 }}>
            <span style={{ fontSize: 14 }}>{w.emoji}</span><Colored text={w.hz} size={16} /><span style={{ fontFamily: "Nunito,sans-serif", fontSize: 11, fontWeight: 800, color: "#a99a80" }}>{w.en}</span>
          </button>
        ))}
      </div>
      <Card style={{ padding: 24 }}>
        <div className="flex items-center justify-center" style={{ gap: 8, fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 13, color: p.role === "self" ? "#7a8f80" : "#b06a2e", background: p.role === "self" ? "#eef6f0" : "#fff3e8", borderRadius: 999, padding: "6px 14px", width: "fit-content", margin: "0 auto 14px" }}>
          {roleBadge(p.role)}
          <button className="btnp" onClick={() => speakEn(roleEn(p.role))} style={{ border: "none", background: "rgba(0,0,0,.05)", borderRadius: 8, padding: "3px 6px", cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 3, fontFamily: "Nunito,sans-serif", fontSize: 11, fontWeight: 800, color: "#7a6f5e" }}><Volume2 size={12} /> EN</button>
        </div>
        <div style={{ textAlign: "center", fontSize: 60, lineHeight: 1 }}>{pic}</div>
        <div className="flex flex-col items-center" style={{ gap: 8, marginTop: 10 }}>
          <div style={{ display: "inline-block" }}><PlayBig onClick={() => speak(p.ask, rate)} size={68} /></div>
          <button onClick={() => setShowEn(!showEn)} style={{ background: "none", border: "none", cursor: "pointer", color: "#c2b49a", fontFamily: "Nunito,sans-serif", fontSize: 13, display: "inline-flex", alignItems: "center", gap: 4 }}><Languages size={13} /> {showEn ? "hide English" : "show English"}</button>
          {showEn && <div className="fadeUp" style={{ fontFamily: "Nunito,sans-serif", color: "#9a8f7e", fontSize: 16 }}>{p.askEn}</div>}
        </div>

        {view === "ask" && (
          <div className="flex flex-col items-center" style={{ gap: 14, marginTop: 18 }}>
            <div style={{ fontFamily: "Nunito,sans-serif", color: "#7a6f5e", fontSize: 15, textAlign: "center" }}>🗣️ Answer out loud in a full sentence, then check.</div>
            {micErr && <div style={{ fontFamily: "Nunito,sans-serif", color: "#a98a55", fontSize: 13 }}>Mic isn't available here — use Build or Show me.</div>}
            <div className="flex flex-wrap justify-center" style={{ gap: 10 }}><Btn onClick={startRec}><Mic size={18} /> Record</Btn><Btn kind="soft" onClick={() => setBuilding(!building)}><Puzzle size={16} /> Build it</Btn><Btn kind="ghost" onClick={showMe}><Eye size={16} /> Show me</Btn></div>
            {building && (
              <div className="fadeUp" style={{ width: "100%", marginTop: 8 }}>
                <div onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); const w = e.dataTransfer.getData("text/plain"); if (w) setBuilt((b) => [...b, w]); }} style={{ minHeight: 54, borderRadius: 14, border: "2px dashed #d8cbb0", background: "#fffdf8", display: "flex", alignItems: "center", justifyContent: "center", padding: "8px 12px", flexWrap: "wrap" }}>{built.length === 0 ? <span style={{ color: "#c2b49a", fontFamily: "Nunito,sans-serif", fontSize: 14 }}>drag or tap ＋ to add · tap a word to hear it</span> : <Colored text={built.join("")} size={26} />}</div>
                <div className="flex flex-wrap justify-center" style={{ gap: 8, marginTop: 12 }}>{chips.map((c, k) => { const isP = PUNCT.includes(c); return (
                  <span key={k} draggable onDragStart={(e) => e.dataTransfer.setData("text/plain", c)} className="btnp" style={{ border: "1px solid #ece2cf", background: isP ? "#f6efe2" : "#fff", borderRadius: 12, padding: isP ? "6px 9px" : "7px 9px 7px 12px", display: "inline-flex", alignItems: "center", gap: 6, cursor: "grab" }}>
                    <span onClick={() => !isP && speak(c, rate)} style={{ cursor: isP ? "default" : "pointer" }}><Colored text={c} size={isP ? 18 : 22} /></span>
                    <button onClick={() => addWord(c)} title="add" style={{ border: "none", background: "#F3E9D6", borderRadius: 7, width: 22, height: 22, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}><Plus size={13} color="#b07a3a" /></button>
                  </span>
                ); })}</div>
                <div className="flex items-center justify-center" style={{ gap: 8, marginTop: 12 }}><Btn kind="ghost" onClick={() => setBuilt(built.slice(0, -1))} style={{ fontSize: 13, padding: "9px 14px" }}>⌫ undo</Btn><Btn onClick={checkBuild} disabled={!built.length}>Check <Check size={16} /></Btn></div>
                {wrong > 0 && <div className="fadeUp" style={{ marginTop: 12, padding: "10px 14px", borderRadius: 12, background: "#fff7e6", border: "1px solid #f0d98a", textAlign: "center" }}><div style={{ fontFamily: "Nunito,sans-serif", color: "#b08a2e", fontWeight: 700, fontSize: 14 }}>{wrong >= 2 ? "Here it is — copy it:" : "Almost! Try again. Hint:"}</div><div className="flex items-center justify-center" style={{ gap: 8, marginTop: 6 }}><Colored text={p.answer} size={22} /><span style={{ fontFamily: "Nunito,sans-serif", color: "#a99a80", fontSize: 13 }}>{p.ansPy}</span><button className="btnp" onClick={() => speak(p.answer, rate)} style={{ border: "none", background: "rgba(0,0,0,.05)", borderRadius: 8, padding: "4px 6px", cursor: "pointer" }}><Volume2 size={14} color="#8a7f6e" /></button></div></div>}
              </div>
            )}
          </div>
        )}
        {view === "recording" && <div className="flex flex-col items-center" style={{ gap: 12, marginTop: 18 }}><button className="pulsemic" onClick={stopRec} style={{ width: 92, height: 92, borderRadius: 999, border: "none", cursor: "pointer", color: "#fff", background: "#DC2626", display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 16px 30px -14px rgba(220,38,38,.6)" }}><Square size={32} fill="#fff" /></button><div style={{ fontFamily: "Nunito,sans-serif", color: "#9a8f7e", fontSize: 14 }}>Recording… say your full sentence, then tap to stop</div></div>}
        {view === "result" && resp && (
          <div className="fadeUp" style={{ marginTop: 18 }}>
            {audioURL && <div className="flex justify-center" style={{ marginBottom: 14 }}><Btn kind="soft" onClick={() => { try { new Audio(audioURL).play(); } catch (e) {} }}><Play size={16} fill="#7a5a2e" /> Hear yourself</Btn></div>}
            <Bobo face={p.role === "self" || p.role === "narrator" ? "🐼" : "👩🏽"}><div style={{ fontWeight: 700 }}>{resp.recast_en}</div><div className="flex items-center" style={{ gap: 8, marginTop: 6 }}><Colored text={resp.recast} size={22} /><button className="btnp" onClick={() => speak(resp.recast, rate)} style={{ border: "none", background: "#F3E9D6", borderRadius: 10, padding: "5px 7px", cursor: "pointer" }}><Volume2 size={15} color="#b07a3a" /></button></div></Bobo>
            <div style={{ marginTop: 14, background: "#eafaf0", border: "1px solid #bfe6cd", borderRadius: 14, padding: "12px 14px" }}><span style={{ fontFamily: "Nunito,sans-serif", fontSize: 12, color: "#7a8f80", fontWeight: 800 }}>YOU SAY</span><div className="flex items-center" style={{ gap: 10, marginTop: 4, flexWrap: "wrap" }}><Colored text={resp.model} size={24} /><span style={{ fontFamily: "Nunito,sans-serif", color: "#7a8f80", fontSize: 14 }}>{resp.model_py}</span><button className="btnp" onClick={() => speak(resp.model, rate)} style={{ border: "none", background: "#fff", borderRadius: 10, padding: "6px 8px", cursor: "pointer" }}><Volume2 size={15} color="#1F9D57" /></button></div></div>
            <div className="flex items-center justify-center" style={{ gap: 10, marginTop: 18, flexWrap: "wrap" }}>{(enough || count >= TRI_MAX) ? <><Btn onClick={onComplete}>I've got it → Read <ChevronRight size={18} /></Btn><Btn kind="ghost" onClick={goNext}>One more</Btn></> : <Btn onClick={goNext}>Next question <ChevronRight size={18} /></Btn>}</div>
          </div>
        )}
      </Card>
    </div>
  );
}

/* ================================================================== */
/*  4 — MATCH (sound -> character, spiraled)                           */
/* ================================================================== */
function MatchSub({ words, rate, onComplete }) {
  const order = useMemo(() => shuffle(words.map((_, i) => i)), [words]);
  const [pos, setPos] = useState(0), [opts, setOpts] = useState([]), [fb, setFb] = useState(null);
  const target = words[order[pos]];
  useEffect(() => { if (!target) return; const others = shuffle(words.filter((w) => w.hz !== target.hz)); const pad = others.length >= 2 ? others.slice(0, 2) : others; setOpts(shuffle([target, ...pad])); setFb(null); const t = setTimeout(() => speak(target.hz, rate), 380); return () => clearTimeout(t); }, [pos]); // eslint-disable-line
  function choose(w) { if (fb && fb.ok) return; if (w.hz === target.hz) { chimeYay(); setFb({ ok: true }); setTimeout(() => { if (pos + 1 >= order.length) onComplete(); else setPos(pos + 1); }, 800); } else { chimeOops(); setFb({ ok: false, wrong: w.hz }); } }
  if (!target) { onComplete(); return null; }
  return (
    <div className="flex flex-col" style={{ gap: 14 }}>
      <Bobo><b>Match the sound to the character.</b> 🔊 Tap play, then pick the character you hear.</Bobo>
      <div className="flex items-center" style={{ gap: 10 }}><div style={{ flex: 1, height: 8, borderRadius: 999, background: "#ece2cf", overflow: "hidden" }}><div style={{ height: "100%", width: (pos / order.length) * 100 + "%", background: "linear-gradient(90deg,#EE8A4E,#E0742F)", transition: "width .3s" }} /></div><span style={{ fontFamily: "Nunito,sans-serif", fontSize: 13, fontWeight: 800, color: "#a99a80" }}>{pos} / {order.length}</span></div>
      <Card style={{ textAlign: "center", padding: 26 }}>
        <div style={{ margin: "4px auto 18px", display: "inline-block" }}><PlayBig onClick={() => speak(target.hz, rate)} size={76} /></div>
        <div className="flex flex-wrap justify-center" style={{ gap: 12 }}>{opts.map((w, i) => { const bad = fb && !fb.ok && fb.wrong === w.hz, good = fb && fb.ok && w.hz === target.hz; return <button key={i} className="opt btnp" onClick={() => choose(w)} style={{ display: "flex", alignItems: "center", justifyContent: "center", padding: "16px 22px", borderRadius: 18, cursor: "pointer", border: "2px solid " + (good ? "#1F9D57" : bad ? "#DC2626" : "#e7dcc8"), background: good ? "#eafaf0" : bad ? "#fdeeee" : "#fffdf8", minWidth: 92 }}><ToneLabel label={w.hz} tones={w.tones} size={34} /></button>; })}</div>
        {fb && fb.ok && <div className="fadeUp flex items-center justify-center" style={{ gap: 8, marginTop: 16, fontFamily: "Nunito,sans-serif", fontWeight: 800, color: "#1F9D57" }}><Check size={18} /> {target.en}</div>}
        {fb && !fb.ok && <div className="fadeUp" style={{ marginTop: 16, fontFamily: "Nunito,sans-serif", fontWeight: 800, color: "#c0524a" }}>Not that one — listen again and try.</div>}
      </Card>
    </div>
  );
}

/* ================================================================== */
/*  5 — READ (cumulative sentences, spiraled)                          */
/* ================================================================== */
function ReadMeter({ streak, reps, lastFast }) {
  return <div className="flex items-center justify-between" style={{ fontFamily: "Nunito,sans-serif" }}>
    <div className="flex items-center" style={{ gap: 8, flex: 1 }}><div style={{ flex: 1, maxWidth: 220, height: 8, borderRadius: 999, background: "#ece2cf", overflow: "hidden" }}><div style={{ height: "100%", width: Math.min(100, (streak / READ_STREAK) * 100) + "%", background: "linear-gradient(90deg,#F2B705,#E0742F)", transition: "width .25s" }} /></div><span style={{ fontSize: 13, color: "#a99a80", fontWeight: 800 }}>{streak} / {READ_STREAK} in a row</span></div>
    <div className="flex items-center" style={{ gap: 10 }}>{lastFast != null && <span style={{ display: "inline-flex", alignItems: "center", gap: 3, fontSize: 13, fontWeight: 800, color: lastFast ? "#E0742F" : "#b8a98e" }}><Zap size={13} fill={lastFast ? "#E0742F" : "none"} />{lastFast ? "fast" : "—"}</span>}<span style={{ fontSize: 13, color: "#a99a80", fontWeight: 800 }}>{reps} done</span></div>
  </div>;
}
function ReadSub({ items, intro, rate, baseline, onComplete, fireConfetti, extra }) {
  const [item, setItem] = useState(null), [reps, setReps] = useState(0), [streak, setStreak] = useState(0), [fb, setFb] = useState(null), [mode, setMode] = useState(extra ? "q" : "intro"), [lastFast, setLastFast] = useState(null);
  const tShow = useRef(0), prevK = useRef(-1);
  useEffect(() => { if (extra) nextItem(); }, []); // eslint-disable-line
  function present(it) { setItem(it); setMode("q"); setFb(null); tShow.current = performance.now(); }
  function nextItem() { let k = Math.floor(Math.random() * items.length); if (k === prevK.current && items.length > 1) k = (k + 1) % items.length; prevK.current = k; const base = items[k]; const correctText = base.opts[base.correct]; const opts = shuffle(base.opts); if (Math.random() < 0.2) { const wi = opts.map((_, i) => i).filter((i) => opts[i] !== correctText); if (wi.length) opts[pick(wi)] = pick(SILLY_READS); } present({ ...base, opts, correct: opts.indexOf(correctText) }); }
  function classify(c) { const now = performance.now(); let rt = now - tShow.current; if (rt < 0) rt = 150; const fast = Math.max(0, rt - baseline) < READ_FAST_MS; setLastFast(fast); return c ? (fast ? "FC" : "SC") : (fast ? "FI" : "SI"); }
  function answer(idx) {
    if (mode !== "q") return; const correct = idx === item.correct; const sig = classify(correct); const meaning = item.opts[item.correct];
    if (sig === "FI") { chimeOops(); setFb({ slip: true }); setTimeout(() => { setFb(null); setMode("q"); tShow.current = performance.now(); }, 1050); return; }
    const newStreak = correct ? streak + 1 : 0, newReps = reps + 1; setStreak(newStreak); setReps(newReps);
    if (correct) chimeYay(); else chimeOops();
    setFb({ ok: correct, sig, hz: item.hz, meaning }); setMode("feedback");
    const done = extra ? newReps >= extra : newStreak >= READ_STREAK;
    speak(item.hz, rate, () => { if (done) { fireConfetti(); fanfare(); setTimeout(onComplete, 500); } else setTimeout(nextItem, 350); });
  }
  if (mode === "intro") return (
    <div className="flex flex-col" style={{ gap: 16 }}>
      <Bobo>Now <b>read</b>. 📖 Match each sentence to its meaning, fast as you can — earlier sentences come back too.</Bobo>
      <Card style={{ padding: 22, textAlign: "center" }}>
        <ToneLabel label={intro.hz} tones={intro.tones} size={42} />
        <div className="flex items-center justify-center" style={{ gap: 8, marginTop: 8 }}><span style={{ fontFamily: "Nunito,sans-serif", color: "#3a3329", fontWeight: 700, fontSize: 16 }}>{intro.en}</span><button className="btnp" onClick={() => speak(intro.hz, rate)} style={{ border: "none", background: "#F3E9D6", borderRadius: 10, padding: "6px 8px", cursor: "pointer" }}><Volume2 size={15} color="#b07a3a" /></button></div>
        <div style={{ marginTop: 18, fontFamily: "Nunito,sans-serif", color: "#7a6f5e", fontSize: 14 }}>Get <b>10 in a row</b> right to finish.</div>
        <div className="flex justify-center" style={{ marginTop: 16 }}><Btn onClick={() => nextItem()}>Start reading <BookOpen size={18} /></Btn></div>
      </Card>
    </div>
  );
  return (
    <div className="flex flex-col" style={{ gap: 14 }}>
      {extra ? <div style={{ textAlign: "center", fontFamily: "Nunito,sans-serif", fontSize: 13, fontWeight: 800, color: "#a99a80" }}>a little more practice · {Math.min(reps, extra)} / {extra}</div> : <ReadMeter streak={streak} reps={reps} lastFast={lastFast} />}
      <Card style={{ textAlign: "center", padding: 28 }}>
        <div style={{ fontFamily: "Nunito,sans-serif", color: "#b8a98e", fontWeight: 800, fontSize: 12, letterSpacing: 1, textTransform: "uppercase", marginBottom: 14 }}>read it · what does it mean?</div>
        <div className="flex items-center justify-center" style={{ gap: 10, padding: "8px 0 16px", flexWrap: "wrap" }}>{item && <ToneLabel label={item.hz} tones={item.tones} size={38} />}{item && <button className="btnp" onClick={() => speak(item.hz, rate)} style={{ border: "none", background: "#F3E9D6", borderRadius: 10, padding: "7px 9px", cursor: "pointer" }}><Volume2 size={16} color="#b07a3a" /></button>}</div>
        {mode === "q" && item && <div className="flex flex-col" style={{ gap: 10 }}>{item.opts.map((o, idx) => <button key={idx} className="opt btnp" onClick={() => answer(idx)} style={{ alignItems: "center", padding: "14px 18px", borderRadius: 16, cursor: "pointer", border: "1px solid #e7dcc8", background: "#fffdf8", fontFamily: "Nunito,sans-serif", fontSize: 17, fontWeight: 700, color: "#3a3329" }}>{o}</button>)}</div>}
        {fb && <div className="fadeUp" style={{ marginTop: 18, padding: "12px 16px", borderRadius: 16, background: fb.slip ? "#fff7e6" : fb.ok ? "#eafaf0" : "#fdeeee", border: "1px solid " + (fb.slip ? "#f0d98a" : fb.ok ? "#bfe6cd" : "#f3c9c9") }}><div className="flex items-center justify-center" style={{ gap: 8, fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 15, color: fb.slip ? "#b08a2e" : fb.ok ? "#1F9D57" : "#c0524a" }}>{fb.slip ? "⚡ Quick tap — look again!" : <>{fb.ok && fb.sig === "FC" && <Zap size={16} fill="#1F9D57" />}{(fb.ok ? "Yes — " : "Not quite — ") + "\u201C" + fb.hz + "\u201D = " + fb.meaning}<button className="btnp" onClick={() => speak(fb.hz, rate)} style={{ border: "none", background: "rgba(0,0,0,.06)", borderRadius: 8, padding: "4px 6px", cursor: "pointer" }}><Volume2 size={14} color="#8a7f6e" /></button></>}</div></div>}
      </Card>
    </div>
  );
}

/* ================================================================== */
/*  6 — WRITE (this sentence)                                          */
/* ================================================================== */
function WriteSub({ cfg, rate, onComplete, fireConfetti }) {
  const target = cfg.write;
  const [built, setBuilt] = useState([]), [msg, setMsg] = useState(null), [solved, setSolved] = useState(false);
  const pal = useMemo(() => {
    const need = Array.from(target);
    const extras = ["这", "是", "你", "我", "他", "很", "饿", "高兴", "难过", "想", "吃", "包子", "苹果", "去", "商店", "没有", "有", "妈妈", "小明"].filter((x) => !need.includes(x));
    return shuffle(Array.from(new Set([...need, ...shuffle(extras).slice(0, 4)]))).concat(PUNCT.slice(0, 3));
  }, [cfg.key]);
  useEffect(() => { setBuilt([]); setMsg(null); setSolved(false); const t = setTimeout(() => speak(target, rate), 400); return () => clearTimeout(t); }, [cfg.key]); // eslint-disable-line
  const check = () => { if (norm(built.join("")) === norm(target)) { chimeYay(); fireConfetti(); setSolved(true); speak(target, rate); } else { chimeOops(); setMsg("Not yet — listen again and build the whole sentence."); } };
  return (
    <div className="flex flex-col" style={{ gap: 14 }}>
      <Bobo>Write it. ✍️ Listen, then build the sentence (tap a character to hear it, ＋ or drag to add).</Bobo>
      <Card style={{ padding: 24 }}>
        <div className="flex items-center justify-center" style={{ gap: 14 }}><span style={{ fontSize: 50 }}>{cfg.sentence.emoji}</span><PlayBig onClick={() => speak(target, rate)} size={56} /></div>
        <div style={{ textAlign: "center", fontFamily: "Nunito,sans-serif", color: "#a99a80", marginTop: 8, fontWeight: 700 }}>{cfg.sentence.en}</div>
        {!solved ? (
          <>
            <div onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); const w = e.dataTransfer.getData("text/plain"); if (w) { setBuilt((b) => [...b, w]); setMsg(null); } }} style={{ minHeight: 58, borderRadius: 14, border: "2px dashed #d8cbb0", background: "#fffdf8", display: "flex", alignItems: "center", justifyContent: "center", padding: "10px 12px", flexWrap: "wrap", marginTop: 18 }}>{built.length === 0 ? <span style={{ color: "#c2b49a", fontFamily: "Nunito,sans-serif", fontSize: 14 }}>drag or tap ＋ to add · tap a character to hear it</span> : <Colored text={built.join("")} size={30} />}</div>
            <div className="flex flex-wrap justify-center" style={{ gap: 8, marginTop: 14 }}>{pal.map((c, k) => { const isP = PUNCT.includes(c); return (
              <span key={k} draggable onDragStart={(e) => e.dataTransfer.setData("text/plain", c)} className="btnp" style={{ border: "1px solid #ece2cf", background: isP ? "#f6efe2" : "#fff", borderRadius: 12, padding: isP ? "6px 9px" : "7px 9px 7px 12px", display: "inline-flex", alignItems: "center", gap: 6, cursor: "grab" }}>
                <span onClick={() => !isP && speak(c, rate)} style={{ cursor: isP ? "default" : "pointer" }}><Colored text={c} size={isP ? 18 : 24} /></span>
                <button onClick={() => { if (!isP) speak(c, rate); setBuilt([...built, c]); setMsg(null); }} title="add" style={{ border: "none", background: "#F3E9D6", borderRadius: 7, width: 22, height: 22, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}><Plus size={13} color="#b07a3a" /></button>
              </span>
            ); })}</div>
            <div className="flex items-center justify-center" style={{ gap: 8, marginTop: 14 }}><Btn kind="ghost" onClick={() => setBuilt(built.slice(0, -1))} style={{ fontSize: 13, padding: "9px 14px" }}>⌫ undo</Btn><Btn onClick={check} disabled={!built.length}>Check <Check size={16} /></Btn></div>
            {msg && <div style={{ marginTop: 10, textAlign: "center", fontFamily: "Nunito,sans-serif", color: "#c0623a", fontSize: 14 }}>{msg}</div>}
          </>
        ) : (
          <div className="fadeUp" style={{ marginTop: 16, textAlign: "center" }}>
            <div style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, color: "#1F9D57", fontSize: 16 }}>✓ Yes! You wrote it.</div>
            <div className="flex items-center justify-center" style={{ gap: 10, marginTop: 10 }}><Colored text={target} size={32} /><button className="btnp" onClick={() => speak(target, rate)} style={{ border: "none", background: "#F3E9D6", borderRadius: 10, padding: "7px 9px", cursor: "pointer" }}><Volume2 size={18} color="#b07a3a" /></button></div>
            <div className="flex items-center justify-center" style={{ gap: 10, marginTop: 18, flexWrap: "wrap" }}><Btn onClick={onComplete}>Continue <ChevronRight size={18} /></Btn><Btn kind="ghost" onClick={() => { setBuilt([]); setSolved(false); setMsg(null); }}>Write it again</Btn></div>
          </div>
        )}
      </Card>
    </div>
  );
}

/* ================================================================== */
/*  APP                                                                */
/* ================================================================== */
/* ================================================================== */
/*  DESCRIBE THE SITUATION — cumulative retell (TPRS 2.0 core)         */
/*  Tier 0: muted timed retell + two-trains self-rating. No mic.       */
/* ================================================================== */
const dtsTarget = (i) => Math.min(90, 15 + i * 10);
const DTS_LIES = [
  { hz: "这是波波", en: "This is BOBO (it's Xiao Ming!)" },
  { hz: "小明很高兴", en: "Xiao Ming is HAPPY (he's hungry!)" },
  { hz: "他想吃苹果", en: "he wants an APPLE (he wants baozi!)" },
  { hz: "他去学校", en: "he goes to SCHOOL (he goes to the store!)" },
  { hz: "商店有包子", en: "the store HAS baozi (it has none!)" },
  { hz: "小明很高兴", en: "Xiao Ming is HAPPY (he's sad here!)" },
  { hz: "妈妈说我有苹果", en: "Mom says she has an APPLE (it's baozi!)" },
  { hz: "小明很难过", en: "Xiao Ming is SAD (he's happy now!)" },
];
const CONNECTORS = [{ hz: "和", en: "and" }, { hz: "可是", en: "but" }, { hz: "因为", en: "because" }];
const fmtT = (s) => (s >= 60 ? Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0") : s + "s");

function Train({ icon, label, value, onPick }) {
  return (
    <div style={{ textAlign: "center" }}>
      <div style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 14, color: "#5a4f3e", marginBottom: 8 }}>{icon} {label}</div>
      <div className="flex justify-center" style={{ gap: 6 }}>
        {[1, 2, 3, 4, 5].map((n) => (
          <button key={n} className="btnp" onClick={() => onPick(n)} style={{ width: 46, height: 46, borderRadius: 14, border: value === n ? "2px solid #E0742F" : "1px solid #e7dcc8", background: value === n ? "#FDEBD7" : "#fffdf8", cursor: "pointer", fontSize: 18 }}>{"🐾".repeat(1)}<div style={{ fontSize: 11, fontWeight: 800, color: "#a99a80" }}>{n}</div></button>
        ))}
      </div>
    </div>
  );
}

function DTSSub({ idx, rate, onComplete, fireConfetti }) {
  const story = SENTENCES.slice(0, idx + 1);
  const target = dtsTarget(idx);
  const [view, setView] = useState("intro");
  const [timeLeft, setTimeLeft] = useState(target);
  const [peek, setPeek] = useState(false);
  const [altStep, setAltStep] = useState(0);
  const [lie, setLie] = useState({ at: -1, step: 0, caught: null, wrongTaps: 0 });
  const [ev, setEv] = useState({ thumbs: null, comp: 0, talk: 0, conn: null, soloRun: false });
  const tRef = useRef(null);
  useEffect(() => () => clearInterval(tRef.current), []);

  const startSolo = () => {
    setView("solo"); setTimeLeft(target); popCue();
    tRef.current = setInterval(() => setTimeLeft((t) => {
      if (t <= 1) { clearInterval(tRef.current); fanfare(); setEv((e) => ({ ...e, soloRun: true })); setTimeout(() => setView("eval"), 600); return 0; }
      if (t === 6) tick();
      return t - 1;
    }), 1000);
  };
  const stopEarly = () => { clearInterval(tRef.current); setEv((e) => ({ ...e, soloRun: true })); setView("eval"); };
  const startLie = () => { const at = Math.floor(Math.random() * story.length); setLie({ at, step: 0, caught: null, wrongTaps: 0 }); setView("lie"); setTimeout(() => speak(at === 0 ? DTS_LIES[0].hz : story[0].sentence.hz, rate), 500); };
  const lieAnswer = (saidLie) => {
    const isLie = lie.step === lie.at;
    if (!isLie && saidLie) { chimeOops(); setLie((l) => ({ ...l, wrongTaps: l.wrongTaps + 1 })); return; } // false alarm: that part was true — try again
    if (isLie && saidLie) { chimeYay(); fireConfetti(); } else chimeYay(); // catching = party; missing = neutral, no leak
    const caught = isLie ? saidLie : lie.caught;
    const next = lie.step + 1;
    setLie((l) => ({ ...l, caught, step: next }));
    setTimeout(() => { if (next < story.length) speak(next === lie.at ? DTS_LIES[next].hz : story[next].sentence.hz, rate); else setView("lieReveal"); }, 600);
  };

  const anchors = (showHz) => (
    <div className="flex justify-center" style={{ gap: 10, flexWrap: "wrap", margin: "14px 0" }}>
      {story.map((s, i) => (
        <div key={s.key} style={{ textAlign: "center", minWidth: 56 }}>
          <div style={{ fontSize: 34 }}>{s.sentence.emoji}</div>
          {showHz && <div style={{ marginTop: 2 }}><Colored text={s.sentence.hz} size={13} /></div>}
        </div>
      ))}
    </div>
  );
  const connChips = idx >= 2 && (
    <div style={{ textAlign: "center", marginTop: 12 }}>
      <div style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 11, color: "#a99a80", letterSpacing: 1, textTransform: "uppercase", marginBottom: 6 }}>bonus words — glue your sentences together!</div>
      <div className="flex justify-center" style={{ gap: 8, flexWrap: "wrap" }}>
        {CONNECTORS.map((c) => <button key={c.hz} className="btnp" onClick={() => speak(c.hz, rate)} style={{ border: "1px solid #ece2cf", background: "#fffdf8", borderRadius: 999, padding: "6px 14px", cursor: "pointer" }}><Colored text={c.hz} size={17} /> <span style={{ fontFamily: "Nunito,sans-serif", fontSize: 12, fontWeight: 800, color: "#a99a80" }}>{c.en}</span></button>)}
      </div>
    </div>
  );

  if (view === "intro") return (
    <div className="flex flex-col" style={{ gap: 16 }}>
      <Bobo big>Storyteller time! 🎙️ Tell me <b>everything</b> you know about the story — out loud, in Chinese, like <b>YOU</b> are the storyteller. Don't worry about perfect. Just keep talking — I'm all ears. 🐼</Bobo>
      <Card style={{ padding: 22, textAlign: "center" }}>
        <div style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 12, color: "#9a8f7e", letterSpacing: 1, textTransform: "uppercase" }}>your story so far · goal: talk for {fmtT(target)}</div>
        {anchors(false)}
        {connChips}
        <div className="flex justify-center" style={{ gap: 10, marginTop: 18, flexWrap: "wrap" }}>
          <Btn onClick={startSolo}>🎙️ I'll tell it!</Btn>
          {idx >= 1 && <Btn kind="ghost" onClick={() => { setAltStep(0); setView("alt"); setTimeout(() => speak(story[0].sentence.hz, rate), 400); }}>🔁 Take turns with 波波</Btn>}
          {idx >= 1 && <Btn kind="ghost" onClick={startLie}>🕵️ Catch 波波's lie!</Btn>}
        </div>
      </Card>
    </div>
  );

  if (view === "solo") return (
    <div className="flex flex-col" style={{ gap: 16 }}>
      <Bobo big face="🐼">{timeLeft > 0 ? <>I'm listening...! Keep going — the pictures will help you remember. 🎧</> : <>Time! 🎉</>}</Bobo>
      <Card style={{ padding: 24, textAlign: "center" }}>
        <div style={{ fontFamily: "'Bricolage Grotesque',sans-serif", fontWeight: 700, fontSize: 64, color: timeLeft <= 5 ? "#E0742F" : "#2c2620", lineHeight: 1 }}>{fmtT(timeLeft)}</div>
        <div style={{ height: 10, background: "#f0e6d2", borderRadius: 999, margin: "16px auto 4px", maxWidth: 320, overflow: "hidden" }}><div style={{ height: "100%", width: ((target - timeLeft) / target) * 100 + "%", background: "linear-gradient(90deg,#F2B705,#E0742F)", borderRadius: 999, transition: "width 1s linear" }} /></div>
        {anchors(peek)}
        <div className="flex justify-center" style={{ gap: 10, flexWrap: "wrap" }}>
          <Btn kind="ghost" onClick={() => setPeek(!peek)}>{peek ? "🙈 Hide words" : "👀 Peek at words"}</Btn>
          {timeLeft <= Math.floor(target / 2) && timeLeft > 0 && <Btn kind="ghost" onClick={stopEarly}>I said everything!</Btn>}
        </div>
      </Card>
    </div>
  );

  if (view === "alt") {
    const myTurn = altStep % 2 === 1, s = story[altStep];
    if (altStep >= story.length) return null;
    return (
      <div className="flex flex-col" style={{ gap: 16 }}>
        <Bobo big>{myTurn ? <>Your turn! Say <b>the next part</b> out loud — the picture is your clue. 🎙️</> : <>My turn! Listen... 🐼🎤</>}</Bobo>
        <Card style={{ padding: 24, textAlign: "center" }}>
          <div style={{ fontSize: 64 }}>{s.sentence.emoji}</div>
          {!myTurn && <div style={{ marginTop: 8 }}><Colored text={s.sentence.hz} size={24} /></div>}
          <div style={{ fontFamily: "Nunito,sans-serif", fontSize: 13, color: "#a99a80", fontWeight: 700, marginTop: 6 }}>part {altStep + 1} of {story.length}</div>
          <div className="flex justify-center" style={{ gap: 10, marginTop: 16 }}>
            {!myTurn && <Btn kind="ghost" onClick={() => speak(s.sentence.hz, rate)}><Volume2 size={17} /> Hear 波波 again</Btn>}
            <Btn onClick={() => { chimeYay(); const n = altStep + 1; if (n >= story.length) { setView("eval"); return; } setAltStep(n); if (n % 2 === 0) setTimeout(() => speak(story[n].sentence.hz, rate), 400); }}>{myTurn ? "I said it! ✓" : "Next →"}</Btn>
          </div>
        </Card>
      </div>
    );
  }

  if (view === "lie") {
    const done = lie.step >= story.length, s = story[Math.min(lie.step, story.length - 1)];
    if (done) return null;
    return (
      <div className="flex flex-col" style={{ gap: 16 }}>
        <Bobo big face="🐼">I'll tell the story... but I hid <b>one lie</b> in it. 🤫 After each part, tap: true or LIE?</Bobo>
        <Card style={{ padding: 24, textAlign: "center" }}>
          <div style={{ fontSize: 60 }}>{s.sentence.emoji}</div>
          <div style={{ fontFamily: "Nunito,sans-serif", fontSize: 13, color: "#a99a80", fontWeight: 700, margin: "6px 0 14px" }}>part {lie.step + 1} of {story.length} · <button onClick={() => speak(lie.step === lie.at ? DTS_LIES[lie.step].hz : s.sentence.hz, rate)} style={{ border: "none", background: "none", cursor: "pointer", color: "#b07a3a", fontWeight: 800 }}>🔊 hear it again</button></div>
          <div className="flex justify-center" style={{ gap: 12 }}>
            <Btn onClick={() => lieAnswer(false)} style={{ background: "linear-gradient(180deg,#34c177,#1F9D57)" }}>✓ 对! True!</Btn>
            <Btn onClick={() => lieAnswer(true)} style={{ background: "linear-gradient(180deg,#f47b5b,#DC2626)" }}>🕵️ 骗人! LIE!</Btn>
          </div>
        </Card>
      </div>
    );
  }

  if (view === "lieReveal") return (
    <div className="flex flex-col" style={{ gap: 16 }}>
      <Bobo big face={lie.caught ? "🐼" : "🐼"}>{lie.caught ? <>You CAUGHT me! 🕵️ Detective-level listening!</> : <>Hehe — I tricked you! 😏 My lie was:</>}</Bobo>
      <Card style={{ padding: 22, textAlign: "center" }}>
        <div style={{ marginBottom: 6 }}><Colored text={DTS_LIES[lie.at].hz} size={26} /></div>
        <div style={{ fontFamily: "Nunito,sans-serif", color: "#7a6f5e", fontSize: 14 }}>{DTS_LIES[lie.at].en}</div>
        <div style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, color: "#5a4f3e", fontSize: 14, marginTop: 14 }}>The truth: <button onClick={() => speak(story[lie.at].sentence.hz, rate)} style={{ border: "none", background: "none", cursor: "pointer", color: "#b07a3a", fontWeight: 800 }}>🔊</button></div>
        <div style={{ marginTop: 4 }}><Colored text={story[lie.at].sentence.hz} size={24} /></div>
        <div style={{ marginTop: 18 }}><Btn onClick={() => setView("eval")}>Continue <ChevronRight size={18} /></Btn></div>
      </Card>
    </div>
  );

  /* eval — thumbs (solo only) + two trains + connector bonus */
  const ready = (!ev.soloRun || ev.thumbs) && ev.comp > 0 && ev.talk > 0 && (idx < 2 || ev.conn !== null);
  return (
    <div className="flex flex-col" style={{ gap: 16 }}>
      <Bobo big>Storytellers always check their <b>two trains</b> 🚂 — what your brain <b>understood</b>, and what your mouth could <b>say</b>. Be honest — there are no wrong answers here!</Bobo>
      <Card style={{ padding: 22 }}>
        <div className="flex flex-col" style={{ gap: 20 }}>
          {ev.soloRun && (
            <div style={{ textAlign: "center" }}>
              <div style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 14, color: "#5a4f3e", marginBottom: 8 }}>⏱️ Did you talk the whole time?</div>
              <div className="flex justify-center" style={{ gap: 8 }}>
                {[["whole", "👍 Whole time!"], ["most", "🤏 Most of it"], ["some", "🌱 A little"]].map(([k, l]) => <button key={k} className="btnp" onClick={() => setEv((e) => ({ ...e, thumbs: k }))} style={{ border: ev.thumbs === k ? "2px solid #E0742F" : "1px solid #e7dcc8", background: ev.thumbs === k ? "#FDEBD7" : "#fffdf8", borderRadius: 999, padding: "9px 16px", cursor: "pointer", fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 13, color: "#5a4f3e" }}>{l}</button>)}
              </div>
            </div>
          )}
          <Train icon="🧠" label="Understanding train — how much made sense?" value={ev.comp} onPick={(n) => setEv((e) => ({ ...e, comp: n }))} />
          <Train icon="🗣️" label="Speaking train — how much could you SAY?" value={ev.talk} onPick={(n) => setEv((e) => ({ ...e, talk: n }))} />
          {idx >= 2 && (
            <div style={{ textAlign: "center" }}>
              <div style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 14, color: "#5a4f3e", marginBottom: 8 }}>🌟 Did you use a bonus word? (和 · 可是 · 因为)</div>
              <div className="flex justify-center" style={{ gap: 8 }}>
                <button className="btnp" onClick={() => { setEv((e) => ({ ...e, conn: true })); fireConfetti(); chimeYay(); }} style={{ border: ev.conn === true ? "2px solid #E0742F" : "1px solid #e7dcc8", background: ev.conn === true ? "#FDEBD7" : "#fffdf8", borderRadius: 999, padding: "9px 16px", cursor: "pointer", fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 13, color: "#5a4f3e" }}>YES! 🎉</button>
                <button className="btnp" onClick={() => setEv((e) => ({ ...e, conn: false }))} style={{ border: ev.conn === false ? "2px solid #E0742F" : "1px solid #e7dcc8", background: ev.conn === false ? "#FDEBD7" : "#fffdf8", borderRadius: 999, padding: "9px 16px", cursor: "pointer", fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 13, color: "#5a4f3e" }}>Not yet</button>
              </div>
              {ev.conn === true && <div style={{ fontFamily: "Nunito,sans-serif", fontSize: 13, color: "#b07a3a", fontWeight: 800, marginTop: 8 }}>波波: "Gluing sentences together?! That's the deep end of Chinese! 🏊"</div>}
            </div>
          )}
          <div className="flex justify-center"><Btn disabled={!ready} onClick={onComplete}>Finish the lesson! <ChevronRight size={18} /></Btn></div>
        </div>
      </Card>
    </div>
  );
}

/* ================================================================== */
/*  LESSON SONGS — placeholder slots for Suno/Flow music videos        */
/*  When a video is ready, set url (mp4 link) and it plays in-app.     */
/* ================================================================== */
const L1 = [
  ["哎! 哎! 这是谁? 这是谁?","āi! āi! zhè shì shéi?","Hey! Hey! Who is this?",13.9,[13.79,14.22,14.61,14.78,14.97,15.94,16.05,16.26]],
  ["这是小明! (对!)","zhè shì Xiǎomíng! (duì!)","This is Xiao Ming! (Right!)",24.5,[24.49,24.63,24.85,25.29,26.66]],
  ["这是小明! (哎!)","zhè shì Xiǎomíng! (āi!)","This is Xiao Ming! (Hey!)",27.9,[27.9,28.07,28.32,28.71,30.54]],
  ["不是披萨! (不是!)","bú shì pīsà!","It's not pizza! (Nope!)",31.4,[31.41,31.53,31.73,32.13,33.09,33.45]],
  ["不是波波! (不是!)","bú shì Bōbo!","It's not Bobo! (Nope!)",34.8,[34.8,34.94,35.16,35.56,36.53,36.87]],
  ["这是谁? 这是谁?","zhè shì shéi?","Who is this? Who is this?",38.2,[38.2,38.37,38.59,39.88,40.05,40.32]],
  ["这! 是! 小! 明!","zhè! shì! xiǎo! míng!","THIS. IS. XIAO. MING.",41.3,[41.18,42.41,42.87,43.73]],
  ["你是你 (你!)","nǐ shì nǐ","You are you (you!)",45.2,[45.12,45.26,45.45,45.99]],
  ["我是我 (我!)","wǒ shì wǒ","I am me (me!)",46.8,[46.77,46.93,47.19,47.61]],
  ["他是谁? 他是小明! (对!)","tā shì shéi? tā shì Xiǎomíng!","Who's he? He's Xiao Ming!",48.6,[48.52,48.66,48.86,49.36,49.5,49.72,50.11,50.66]],
  ["这是妈妈 (妈妈!)","zhè shì māma","This is Mom (Mom!)",52,[51.91,52.07,52.29,52.69,53.62,54]],
  ["他是小明 (小明!)","tā shì Xiǎomíng","He is Xiao Ming!",55.4,[55.28,55.49,55.74,56.1,57.07,57.46]],
  ["是不是? 是! 对不对? 对!","shì bú shì? shì! duì bú duì? duì!","Is it? Yes! Right? Right!",58.9,[58.83,58.96,59.17,59.53,63.55,63.68,64.16,64.98]],
  ["这是小明! (对!)","zhè shì Xiǎomíng! (duì!)","This is Xiao Ming! (Right!)",72.5,[72.48,72.67,72.84,73.28,74.64]],
  ["这是小明! (哎!)","zhè shì Xiǎomíng! (āi!)","This is Xiao Ming! (Hey!)",75.9,[75.9,76.04,76.27,76.68,78.1]],
  ["不是披萨! 不是巧克力!","bú shì pīsà! bú shì qiǎokèlì!","Not pizza! Not chocolate!",79.4,[79.39,79.5,79.72,80.1,81.07,81.19,81.42,81.63,81.87]],
  ["这! 是! 小! 明!","zhè! shì! xiǎo! míng!","THIS. IS. XIAO. MING.",85.9,[85.92,87,87.42,88.28]],
  ["小明. 小明. 对.","Xiǎomíng. Xiǎomíng. duì.","Xiao Ming. Xiao Ming. Yep.",92.8,[92.64,93.14,94.26,94.62,95.22]],
].map(([hz, py, en, t, ct]) => ({ hz, py, en, t, ct }));

const SONGS = [
  { key: "s1", title: "这是小明！(This Is Xiao Ming!)", vibe: "name-game banger", urls: ["https://ortonp-lang.github.io/storylab-songs/track1-zheshixiaoming.mp3.mp3", "https://raw.githubusercontent.com/ortonp-lang/storylab-songs/main/track1-zheshixiaoming.mp3.mp3", "https://github.com/ortonp-lang/storylab-songs/raw/64f7543fec8f991b1669fc465fd7e98c32f01422/track1-zheshixiaoming.mp3.mp3"], lyrics: L1 },
  { key: "s2", title: "我很饿！(I'm SO Hungry!)", vibe: "dramatic hunger anthem", urls: null, lyrics: null },
  { key: "s3", title: "包子梦 (Baozi Dream)", vibe: "dreamy snack ballad", urls: null, lyrics: null },
  { key: "s4", title: "去商店！(To the Store!)", vibe: "marching adventure", urls: null, lyrics: null },
  { key: "s5", title: "没有包子？！(NO BAOZI?!)", vibe: "telenovela tragedy", urls: null, lyrics: null },
  { key: "s6", title: "伤心小明 (Sad, Sad Xiao Ming)", vibe: "world's saddest violin", urls: null, lyrics: null },
  { key: "s7", title: "妈妈说 (Mom Says...)", vibe: "good-news gospel", urls: null, lyrics: null },
  { key: "s8", title: "吃包子！(Eat That Baozi!)", vibe: "victory party", urls: null, lyrics: null },
];
const HIT_SONG = { key: "hit", title: "包子之歌 (The Baozi Song) — THE HIT 🏆", vibe: "the whole story, one banger", urls: null, lyrics: null };
const songByIdx = (i) => (i === 8 ? HIT_SONG : SONGS[i]);
const isHanziChar = (c) => /[\u4e00-\u9fff]/.test(c);

/* ---------- per-lesson structure words for the Circle intro ---------- */
const STRUCT_WORDS = {
  s1: [{ hz: "这", en: "this", emoji: "👇" }, { hz: "是", en: "is", emoji: "🟰" }],
  s2: [{ hz: "很", en: "very / so", emoji: "💯" }],
  s3: [{ hz: "想", en: "wants to", emoji: "💭" }, { hz: "吃", en: "eat", emoji: "😋" }],
  s4: [{ hz: "去", en: "goes to", emoji: "🏃" }],
  s5: [{ hz: "有", en: "has", emoji: "✅" }, { hz: "没有", en: "does NOT have", emoji: "🚫" }],
  s6: [{ hz: "很", en: "very / so", emoji: "💯" }],
  s7: [{ hz: "说", en: "says", emoji: "💬" }, { hz: "有", en: "has", emoji: "✅" }],
  s8: [{ hz: "吃", en: "eats", emoji: "😋" }],
};

/* ---------- shared mic manager: one permission, warm stream, idle release ---------- */
const MIC = { stream: null, timer: null };
async function getMic() {
  if (MIC.stream && MIC.stream.getTracks().some((t) => t.readyState === "live")) { clearTimeout(MIC.timer); return MIC.stream; }
  MIC.stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false } });
  return MIC.stream;
}
function releaseMicSoon(ms) {
  clearTimeout(MIC.timer);
  MIC.timer = setTimeout(() => { try { if (MIC.stream) MIC.stream.getTracks().forEach((t) => t.stop()); } catch (e) {} MIC.stream = null; }, ms == null ? 45000 : ms);
}
function b64ToUrl(b64) { try { const bin = atob(b64); const arr = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i); return URL.createObjectURL(new Blob([arr], { type: "audio/mpeg" })); } catch (e) { return null; } }

/* ================================================================== */
/*  KARAOKE MACHINE — in-app, tone-colored, character-synced          */
/* ================================================================== */
function KaraokeMachine({ song, onClose, fireConfetti }) {
  const audRef = useRef(null), fileRef = useRef(null), endRef = useRef(false);
  const [src, setSrc] = useState(undefined);     // undefined=checking, null=need file, string=ready
  const [started, setStarted] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [t, setT] = useState(0), [dur, setDur] = useState(0);
  const [showPy, setShowPy] = useState(true), [showEn, setShowEn] = useState(false);
  const lines = song.lyrics || [];

  const urlIdx = useRef(0);
  const urlList = song.urls || [];
  const [netNote, setNetNote] = useState("");
  const loadFallback = async () => {
    try { const r = await window.storage.get("karaoke-audio-" + song.key); if (r && r.value) { setSrc(b64ToUrl(r.value)); return; } } catch (e) {}
    setSrc(null);
  };
  useEffect(() => {
    let live = true;
    urlIdx.current = 0;
    (async () => {
      if (urlList.length) { if (live) setSrc(urlList[0]); return; }
      try { const r = await window.storage.get("karaoke-audio-" + song.key); if (live && r && r.value) { setSrc(b64ToUrl(r.value)); return; } } catch (e) {}
      if (live) setSrc(null);
    })();
    return () => { live = false; };
  }, [song.key]);
  const onAudioError = () => {
    if (urlIdx.current + 1 < urlList.length) { urlIdx.current++; setNetNote("🎵 trying source " + (urlIdx.current + 1) + " of " + urlList.length + "..."); setSrc(urlList[urlIdx.current]); }
    else if (urlIdx.current < urlList.length) { urlIdx.current = urlList.length; setNetNote(""); loadFallback(); }
  };
  useEffect(() => {   // stall watchdog: sandboxes can block a stream without firing an error
    if (typeof src !== "string") return;
    let ok = false; const a = audRef.current;
    const mark = () => { ok = true; setNetNote(""); };
    if (a) { if (a.readyState >= 3) mark(); else a.addEventListener("canplay", mark, { once: true }); }
    const w = setTimeout(() => { if (!ok) onAudioError(); }, 6000);
    return () => { clearTimeout(w); if (a) a.removeEventListener("canplay", mark); };
  }, [src]);

  useEffect(() => {
    const iv = setInterval(() => {
      const a = audRef.current; if (!a) return;
      setT(a.currentTime); setDur(a.duration || 0); setPlaying(!a.paused);
      if (!endRef.current && a.duration && a.currentTime > a.duration - 1.2) { endRef.current = true; if (fireConfetti) fireConfetti(); }
    }, 70);
    return () => clearInterval(iv);
  }, []);

  const pickFile = (e) => {
    const f = e.target.files && e.target.files[0]; if (!f) return;
    const rd = new FileReader();
    rd.onload = () => {
      const b64 = String(rd.result).split(",")[1];
      setSrc(b64ToUrl(b64));
      (async () => { try { await window.storage.set("karaoke-audio-" + song.key, b64); } catch (err) { /* too big or unavailable — session-only */ } })();
    };
    rd.readAsDataURL(f);
  };
  const fmtK = (x) => isFinite(x) ? Math.floor(x / 60) + ":" + String(Math.floor(x % 60)).padStart(2, "0") : "0:00";
  let li = -1; for (let i = 0; i < lines.length; i++) if (lines[i].t != null && t >= lines[i].t) li = i;
  const cur = li >= 0 ? lines[li] : null;

  const hzLine = (line, px, dim) => {
    if (!line) return null;
    if (!dim && line.ct && line.ct.length) {
      let sung = -1;
      for (let i = 0; i < line.ct.length; i++) if (t >= line.ct[i]) sung = i;
      let k = -1;
      return Array.from(line.hz).map((c, i) => {
        const h = isHanziChar(c); if (h) k++;
        const kk = h ? k : Math.max(0, k);
        const tone = CHARTONE[c];
        return <span key={i} className={tone != null ? "tone" + tone : ""} style={{ display: "inline-block", fontSize: px, fontWeight: 900, opacity: kk <= sung ? 1 : 0.22, transform: h && kk === sung ? "scale(1.22) translateY(-3px)" : "none", transition: "opacity .12s ease, transform .15s ease" }}>{c}</span>;
      });
    }
    return <span style={{ opacity: dim ? 0.32 : 1 }}><Colored text={line.hz} size={px} /></span>;
  };

  if (src === undefined) return <Card style={{ padding: 30, textAlign: "center" }}><div style={{ fontSize: 40 }}>🎤</div><div style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, color: "#7a6f5e", marginTop: 8 }}>Loading the song...</div></Card>;
  if (src === null) return (
    <Card style={{ padding: 28, textAlign: "center" }}>
      <div style={{ fontSize: 44 }}>🎵</div>
      <div style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 17, color: "#3a3329", marginTop: 6 }}>{song.title}</div>
      <div style={{ fontFamily: "Nunito,sans-serif", fontSize: 13, color: "#a99a80", fontWeight: 700, marginTop: 8, maxWidth: 380, marginLeft: "auto", marginRight: "auto" }}>First time on this device: load the song file once. It saves here so the karaoke works every time after.</div>
      <input ref={fileRef} type="file" accept="audio/*" style={{ display: "none" }} onChange={pickFile} />
      <div className="flex justify-center" style={{ gap: 10, marginTop: 16, flexWrap: "wrap" }}>
        <Btn onClick={() => fileRef.current && fileRef.current.click()}>📂 Load the song (mp3)</Btn>
        <Btn kind="ghost" onClick={onClose}>← Back</Btn>
      </div>
    </Card>
  );
  return (
    <div className="flex flex-col" style={{ gap: 12 }}>
      <div className="flex items-center" style={{ justifyContent: "space-between" }}>
        <div style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 15, color: "#3a3329" }}>🎤 {song.title}</div>
        <Btn kind="ghost" onClick={onClose}>✕ Close</Btn>
      </div>
      <Card style={{ padding: 22, position: "relative", overflow: "hidden" }}>
        <div style={{ minHeight: 300, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", textAlign: "center", gap: 6 }}>
          {playing && <div style={{ position: "absolute", top: 10, left: "50%", transform: "translateX(-50%)", fontSize: 30, animation: "discoswing 2.2s ease-in-out infinite" }}>🪩</div>}
          <div style={{ minHeight: "1.5em" }}>{li > 0 ? hzLine(lines[li - 1], 18, true) : null}</div>
          <div style={{ minHeight: "1.6em", lineHeight: 1.35 }}>{cur ? hzLine(cur, 40, false) : <span style={{ fontSize: 22, color: "#c9b88f", fontWeight: 800 }}>🎵 ...</span>}</div>
          <div style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 15, color: "#7a6f5e", minHeight: "1.3em" }}>{showPy && cur ? cur.py : ""}</div>
          <div style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 13, color: "#a99a80", minHeight: "1.3em" }}>{showEn && cur ? cur.en : ""}</div>
          <div style={{ minHeight: "1.5em" }}>{li + 1 < lines.length ? hzLine(lines[li + 1], 18, true) : null}</div>
          <div style={{ position: "absolute", bottom: 6, right: 12, fontSize: 42, transformOrigin: "50% 90%", animation: playing ? "backupdance 1.1s ease-in-out infinite" : "none" }}>🐼</div>
          {!started && (
            <div onClick={() => { const a = audRef.current; if (a) a.play().then(() => setStarted(true)).catch(() => {}); }} style={{ position: "absolute", inset: 0, background: "rgba(255,251,242,.93)", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 8, cursor: "pointer", borderRadius: 18 }}>
              <div style={{ fontSize: 56, animation: "pulse2 1.4s ease-in-out infinite" }}>🎤</div>
              <div style={{ fontFamily: "Nunito,sans-serif", fontWeight: 900, color: "#7a6f5e" }}>Tap to start the song!</div>
              {netNote && <div style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 12, color: "#b8a370" }}>{netNote}</div>}
            </div>
          )}
        </div>
        <div onClick={(e) => { const a = audRef.current; if (!a || !a.duration) return; const r = e.currentTarget.getBoundingClientRect(); a.currentTime = ((e.clientX - r.left) / r.width) * a.duration; endRef.current = a.currentTime > a.duration - 1.2; }} style={{ height: 12, background: "#f0e6d2", borderRadius: 999, cursor: "pointer", overflow: "hidden", marginTop: 8 }}>
          <div style={{ height: "100%", width: (dur ? (t / dur) * 100 : 0) + "%", background: "linear-gradient(90deg,#F2B705,#E0742F)", borderRadius: 999 }} />
        </div>
        <div className="flex justify-center items-center" style={{ gap: 8, marginTop: 10, flexWrap: "wrap" }}>
          <span style={{ fontFamily: "Nunito,sans-serif", fontWeight: 900, fontSize: 12, color: "#a99a80", minWidth: 76, textAlign: "center" }}>{fmtK(t)} / {fmtK(dur)}</span>
          <button className="btnp" onClick={() => { const a = audRef.current; if (a) { a.currentTime = 0; endRef.current = false; a.play(); } }} style={{ border: "1px solid #e7dcc8", background: "#fffdf8", borderRadius: 999, padding: "8px 13px", cursor: "pointer", fontWeight: 900 }}>⏮</button>
          <button className="btnp" onClick={() => { const a = audRef.current; if (a) a.currentTime = Math.max(0, a.currentTime - 3); }} style={{ border: "1px solid #e7dcc8", background: "#fffdf8", borderRadius: 999, padding: "8px 13px", cursor: "pointer", fontWeight: 900 }}>⏪ 3s</button>
          <button className="btnp" onClick={() => { const a = audRef.current; if (a) { if (a.paused) a.play().then(() => setStarted(true)).catch(() => {}); else a.pause(); } }} style={{ border: "none", background: "linear-gradient(180deg,#F2B705,#E0742F)", color: "#fff", borderRadius: 999, padding: "10px 22px", cursor: "pointer", fontWeight: 900, fontSize: 15 }}>{playing ? "⏸ Pause" : "▶ Play"}</button>
          <select onChange={(e) => { const a = audRef.current; if (a) a.playbackRate = parseFloat(e.target.value); e.target.blur(); }} defaultValue="1" className="btnp" style={{ border: "1px solid #e7dcc8", background: "#fffdf8", borderRadius: 999, padding: "8px 10px", cursor: "pointer", fontWeight: 900, fontFamily: "Nunito,sans-serif" }}>
            <option value="0.5">0.5×</option><option value="0.75">0.75×</option><option value="0.85">0.85×</option><option value="1">1×</option><option value="1.25">1.25×</option><option value="1.5">1.5×</option><option value="2">2×</option>
          </select>
          <button className="btnp" onClick={() => setShowPy(!showPy)} style={{ border: showPy ? "2px solid #E0742F" : "1px solid #e7dcc8", background: showPy ? "#FDEBD7" : "#fffdf8", borderRadius: 999, padding: "8px 13px", cursor: "pointer", fontWeight: 900, color: showPy ? "#b05c1f" : "#5a4f3e" }}>拼音</button>
          <button className="btnp" onClick={() => setShowEn(!showEn)} style={{ border: showEn ? "2px solid #E0742F" : "1px solid #e7dcc8", background: showEn ? "#FDEBD7" : "#fffdf8", borderRadius: 999, padding: "8px 13px", cursor: "pointer", fontWeight: 900, color: showEn ? "#b05c1f" : "#5a4f3e" }}>English</button>
        </div>
      </Card>
      <audio ref={audRef} src={src} preload="auto" onError={onAudioError} />
    </div>
  );
}

/* ================================================================== */
/*  JUKEBOX — collected songs                                          */
/* ================================================================== */
function Jukebox({ completed, onSing, onClose }) {
  const hitUnlocked = completed.length >= SENTENCES.length;
  const collected = completed.length + (hitUnlocked ? 1 : 0);
  const all = [...SONGS.map((s, i) => ({ ...s, i, unlocked: completed.includes(i), lockLabel: "Finish Lesson " + (i + 1) })), { ...HIT_SONG, i: 8, unlocked: hitUnlocked, lockLabel: "Finish the whole story" }];
  return (
    <div className="flex flex-col" style={{ gap: 12 }}>
      <Bobo big>Your song collection! 🎵 You've collected <b>{collected} of {all.length}</b>. Finish lessons to unlock more bangers.</Bobo>
      {all.map((s) => (
        <Card key={s.key} style={{ padding: 14, opacity: s.unlocked ? 1 : 0.55 }}>
          <div className="flex items-center" style={{ gap: 12 }}>
            <span style={{ fontSize: 30, flexShrink: 0 }}>{s.unlocked ? "🎵" : "🔒"}</span>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 15, color: "#3a3329" }}>{s.title}</div>
              <div style={{ fontFamily: "Nunito,sans-serif", fontSize: 12, color: "#a99a80", fontWeight: 700 }}>{s.unlocked ? s.vibe : s.lockLabel}</div>
            </div>
            {s.unlocked && (s.lyrics || (s.urls && s.urls.length)) && <Btn onClick={() => onSing(s.i)}>🎤 Sing</Btn>}
            {s.unlocked && !s.lyrics && !(s.urls && s.urls.length) && <span style={{ fontFamily: "Nunito,sans-serif", fontSize: 11, fontWeight: 800, color: "#c9b88f" }}>🎬 in the studio</span>}
          </div>
        </Card>
      ))}
      <div className="flex justify-center"><Btn kind="ghost" onClick={onClose}>← Back</Btn></div>
    </div>
  );
}

function SongPanel({ idx, onDone, backLabel, onSing }) {
  const song = SONGS[idx];
  const playable = song && (song.lyrics || (song.urls && song.urls.length));
  return (
    <div className="flex flex-col" style={{ gap: 14 }}>
      <Bobo big>🎉 You unlocked a <b>SONG</b>! It's yours to keep — find it anytime in 🎵 Songs.</Bobo>
      <Card style={{ padding: 20, textAlign: "center", border: "2px solid #f3d6ae", background: "linear-gradient(180deg,#fffdf8,#FDF8EE)" }}>
        <div style={{ fontSize: 44 }}>🎵</div>
        <div style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 18, color: "#3a3329", marginTop: 4 }}>{song.title}</div>
        <div style={{ fontFamily: "Nunito,sans-serif", fontSize: 13, color: "#a99a80", fontWeight: 700, marginTop: 2 }}>{song.vibe}</div>
        <div className="flex justify-center" style={{ gap: 10, marginTop: 14, flexWrap: "wrap" }}>
          {playable ? <Btn onClick={() => onSing(idx)}>🎤 Sing it now!</Btn> : <span style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 13, color: "#b8a370" }}>🎬 波波 is in the recording studio — coming soon!</span>}
        </div>
      </Card>
      {idx === SENTENCES.length - 1 && (
        <Card style={{ padding: 20, textAlign: "center", border: "2px solid #E0742F" }}>
          <div style={{ fontSize: 44 }}>🏆</div>
          <div style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 18, color: "#3a3329" }}>{HIT_SONG.title}</div>
          {(HIT_SONG.lyrics || (HIT_SONG.urls && HIT_SONG.urls.length)) ? <div style={{ marginTop: 12 }}><Btn onClick={() => onSing(8)}>🎤 Sing the HIT!</Btn></div> : <div style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 13, color: "#b8a370", marginTop: 8 }}>🎬 coming soon!</div>}
        </Card>
      )}
      <div className="flex justify-center"><Btn onClick={onDone}>{backLabel || "Continue"} <ChevronRight size={18} /></Btn></div>
    </div>
  );
}

const STEPS = [["listen", "Listen"], ["circle", "Circle"], ["triangle", "Triangle"], ["match", "Match"], ["read", "Read"], ["write", "Write"], ["dts", "Tell It"]];
export default function App() {
  const [phase, setPhase] = useState("boot"), [idx, setIdx] = useState(0), [sub, setSub] = useState("listen"), [rate, setRate] = useState(0.82), [baseline, setBaseline] = useState(330), [confetti, setConfetti] = useState(0), [noVoice, setNoVoice] = useState(false), [completed, setCompleted] = useState([]);
  useEffect(() => { try { window.speechSynthesis.getVoices(); window.speechSynthesis.onvoiceschanged = () => setNoVoice(!pickZhVoice()); setTimeout(() => setNoVoice(!pickZhVoice()), 700); } catch (e) {} }, []);
  useEffect(() => { loadProgress().then((p) => { if (p && Array.isArray(p.completed) && p.completed.length) { setCompleted(p.completed); if (p.baseline) setBaseline(p.baseline); if (p.rate) setRate(p.rate); setPhase("welcome"); } else setPhase("cal"); }); }, []);
  const cfg = SENTENCES[idx]; const fire = () => setConfetti((c) => c + 1);
  const prevPhase = useRef("cal");
  const [partyPreview, setPartyPreview] = useState(null);
  const [gate, setGate] = useState("checking");
  useEffect(() => { (async () => { try { const r = await window.storage.get("storylab-gate"); setGate(r && r.value === "open" ? "open" : "locked"); } catch (e) { setGate("locked"); } })(); }, []);
  const unlock = () => { setGate("open"); (async () => { try { await window.storage.set("storylab-gate", "open"); } catch (e) {} })(); };
  const nextUndone = SENTENCES.findIndex((_, i) => !completed.includes(i));
  const resumeIdx = nextUndone === -1 ? 0 : nextUndone;
  const stepKey = ["listen", "circle", "triangle", "match", "write", "dts"].includes(sub) ? sub : sub.indexOf("read") === 0 ? "read" : sub;
  const nextSentence = () => { const nc = completed.includes(idx) ? completed : [...completed, idx]; setCompleted(nc); saveProgress({ completed: nc, baseline, rate }); setPhase("celebrate"); };
  const songFrom = useRef("lesson");
  const [songSel, setSongSel] = useState(0);
  const karaokeFrom = useRef("jukebox"); const jukeFrom = useRef("welcome");
  const singSong = (i, from) => { setSongSel(i); karaokeFrom.current = from; setPhase("karaoke"); };
  const openJukebox = () => { if (phase !== "jukebox" && phase !== "karaoke") jukeFrom.current = phase; setPhase("jukebox"); };
  if (gate !== "open") return (
    <div style={{ minHeight: "100vh", background: "radial-gradient(1000px 600px at 50% -10%, #fff7e9, #f4ecdc)" }}>
      <style>{CSS}</style>
      {gate === "locked" && <GateScreen onUnlock={unlock} />}
    </div>
  );
  const afterCelebrate = () => { songFrom.current = "lesson"; setPhase("song"); };
  const goLesson = (i) => { setIdx(i); setSub("listen"); setPhase("lesson"); };
  const openMap = () => { if (phase !== "map") prevPhase.current = ["celebrate", "boot"].includes(phase) ? "after" : phase; setPhase("map"); };
  return (
    <div style={{ position: "relative", minHeight: "100vh", width: "100%", fontFamily: "Nunito,sans-serif", background: "radial-gradient(1100px 560px at 50% -8%, #FFF7E9 0%, #FBF6EC 46%, #F4ECDC 100%)", overflowX: "hidden" }}>
      <style>{CSS}</style>
      <div style={{ position: "absolute", inset: 0, backgroundImage: "radial-gradient(rgba(180,150,90,.10) 1px, transparent 1px)", backgroundSize: "22px 22px", pointerEvents: "none" }} />
      <Confetti seed={confetti} />
      <div style={{ position: "relative", maxWidth: 600, margin: "0 auto", padding: "22px 18px 64px" }}>
        <div className="flex items-center justify-between" style={{ marginBottom: 14 }}>
          <div className="flex items-center" style={{ gap: 10 }}><span style={{ fontSize: 28, animation: "bobble 3.4s ease-in-out infinite" }}>🐼</span><div><div style={{ fontFamily: "'Bricolage Grotesque',sans-serif", fontWeight: 700, fontSize: 20, color: "#2c2620", lineHeight: 1 }}>Story Lab</div><div style={{ fontSize: 12, color: "#a99a80", fontWeight: 700 }}>小明 & the baozi · 8 sentences</div></div></div>
          <div className="flex items-center" style={{ gap: 12 }}>
            <button className="btnp" onClick={openJukebox} style={{ border: "1px solid #e7dcc8", background: "#fffdf8", borderRadius: 999, padding: "8px 14px", cursor: "pointer", fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 13, color: "#5a4f3e", display: "inline-flex", alignItems: "center", gap: 6 }}>🎵 Songs</button>
            <button className="btnp" onClick={openMap} style={{ border: "1px solid #e7dcc8", background: "#fffdf8", borderRadius: 999, padding: "8px 14px", cursor: "pointer", fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 13, color: "#5a4f3e", display: "inline-flex", alignItems: "center", gap: 6 }}>🗺️ Lessons</button>
            <div className="flex flex-col items-end" style={{ gap: 2 }}>
              <div className="flex items-center" style={{ gap: 6 }}><span style={{ fontSize: 16 }} title="audio speed">🐢</span><input type="range" min={0.55} max={1} step={0.05} value={rate} onChange={(e) => setRate(parseFloat(e.target.value))} style={{ width: 92, accentColor: "#E0742F" }} title="audio speed" /><span style={{ fontSize: 16 }} title="audio speed">🐰</span></div>
              <span style={{ fontFamily: "Nunito,sans-serif", fontSize: 10, color: "#b8a98e", fontWeight: 800, letterSpacing: 0.5 }}>AUDIO SPEED</span>
            </div>
          </div>
        </div>

        {phase === "lesson" && (
          <>
            <div className="flex items-center justify-center" style={{ gap: 7, marginBottom: 10 }}>{SENTENCES.map((s, i) => <span key={s.key} style={{ width: i === idx ? 22 : 8, height: 8, borderRadius: 999, background: i < idx ? "#E0A24A" : i === idx ? "#E0742F" : "#e7dcc8", transition: "all .3s" }} />)}<span style={{ marginLeft: 6, fontFamily: "Nunito,sans-serif", fontSize: 12, fontWeight: 800, color: "#a99a80" }}>sentence {idx + 1}/{SENTENCES.length}</span></div>
            <div className="flex items-center justify-center" style={{ gap: 4, marginBottom: 16, flexWrap: "wrap" }}>{STEPS.map(([k, label], i) => { const ci = STEPS.findIndex((s) => s[0] === stepKey); const active = stepKey === k, done = ci > i; return <div key={k} className="flex items-center" style={{ gap: 4 }}><span style={{ fontFamily: "Nunito,sans-serif", fontWeight: 800, fontSize: 12, color: active ? "#E0742F" : done ? "#c6a878" : "#cabfa8" }}>{done ? "✓" : label}</span>{i < STEPS.length - 1 && <ChevronRight size={11} color="#d8cbb0" />}</div>; })}</div>
          </>
        )}
        {noVoice && phase !== "cal" && <div style={{ marginBottom: 14, fontSize: 13, fontFamily: "Nunito,sans-serif", color: "#a98a55", background: "#fdf4e3", border: "1px solid #f0e2c4", borderRadius: 12, padding: "8px 12px" }}>🔊 No Chinese voice found — audio is the whole point, so use Chrome or add a Chinese voice in your system settings.</div>}

        {phase === "cal" && <Calibrate onDone={(b) => { setBaseline(b); saveProgress({ completed, baseline: b, rate }); goLesson(resumeIdx); }} />}
        {phase === "welcome" && (
          <div className="flex flex-col" style={{ gap: 16 }}>
            <Bobo big>Welcome back! 🐼 I kept your spot warm. You've finished <b>{completed.length} of {SENTENCES.length}</b> lessons{nextUndone === -1 ? <> — the WHOLE story!</> : <> — next up: <b>Lesson {resumeIdx + 1}</b> {SENTENCES[resumeIdx].sentence.emoji}</>}</Bobo>
            <Card style={{ padding: 22, textAlign: "center" }}>
              <div className="flex justify-center" style={{ gap: 8, flexWrap: "wrap", marginBottom: 18 }}>{SENTENCES.map((s, i) => <div key={s.key} style={{ width: 44, height: 44, borderRadius: 14, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 20, background: completed.includes(i) ? "#EAF7EE" : "#fffdf8", border: completed.includes(i) ? "1.5px solid #bfe3c8" : i === resumeIdx ? "2px solid #E0742F" : "1px solid #e7dcc8" }}>{completed.includes(i) ? "✓" : s.sentence.emoji}</div>)}</div>
              <div className="flex justify-center" style={{ gap: 10, flexWrap: "wrap" }}>
                {nextUndone !== -1 && <Btn onClick={() => goLesson(resumeIdx)}>Continue — Lesson {resumeIdx + 1} <ChevronRight size={18} /></Btn>}
                {nextUndone === -1 && <Btn onClick={() => setPhase("finale")}>Finish the story! 🏆</Btn>}
                <Btn kind="ghost" onClick={openMap}>🗺️ Pick a lesson</Btn>
                <Btn kind="ghost" onClick={() => setPhase("cal")}>⚡ Redo tap warm-up</Btn>
              </div>
            </Card>
          </div>
        )}
        {phase === "after" && (
          <div className="flex flex-col" style={{ gap: 16 }}>
            <Bobo big>Lesson {idx + 1} is in the books — <b>{LESSON_BADGES[idx]}</b> earned! 🎉 Your progress is saved. What now?</Bobo>
            <Card style={{ padding: 22, textAlign: "center" }}>
              <div className="flex justify-center" style={{ gap: 8, flexWrap: "wrap", marginBottom: 18 }}>{SENTENCES.map((s, i) => <div key={s.key} style={{ width: 38, height: 38, borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 17, background: completed.includes(i) ? "#EAF7EE" : "#fffdf8", border: completed.includes(i) ? "1.5px solid #bfe3c8" : "1px solid #e7dcc8" }}>{completed.includes(i) ? "✓" : s.sentence.emoji}</div>)}</div>
              <div className="flex justify-center" style={{ gap: 10, flexWrap: "wrap" }}>
                {idx + 1 < SENTENCES.length ? <Btn onClick={() => goLesson(idx + 1)}>Lesson {idx + 2} {SENTENCES[idx + 1].sentence.emoji} <ChevronRight size={18} /></Btn> : <Btn onClick={() => setPhase("finale")}>Finish the story! 🏆</Btn>}
                <Btn kind="ghost" onClick={openMap}>🗺️ Lesson Map</Btn>
                <Btn kind="ghost" onClick={() => setPhase("bye")}>👋 Done for today</Btn>
              </div>
            </Card>
          </div>
        )}
        {phase === "song" && <SongPanel idx={idx} onDone={() => setPhase(songFrom.current === "map" ? "map" : "after")} backLabel={songFrom.current === "map" ? "← Back to map" : null} onSing={(i) => singSong(i, "song")} />}
        {phase === "jukebox" && <Jukebox completed={completed} onSing={(i) => singSong(i, "jukebox")} onClose={() => setPhase(jukeFrom.current)} />}
        {phase === "karaoke" && <KaraokeMachine song={songByIdx(songSel)} fireConfetti={fire} onClose={() => setPhase(karaokeFrom.current)} />}
        {phase === "bye" && <Cheer title="Great work today! 👋" sub={"Your progress is saved — " + completed.length + " of " + SENTENCES.length + " lessons done. 波波 will be here when you come back!"} onNext={() => setPhase("welcome")} nextLabel="Actually... one more! 🐼" />}
        {phase === "map" && <LessonMap rate={rate} currentIdx={idx} completed={completed} onJump={(i, k) => { setIdx(i); setSub(k); setPhase("lesson"); }} onParty={(i) => setPartyPreview(i)} onSong={(i) => { setIdx(i); songFrom.current = "map"; setPhase("song"); }} onClose={() => setPhase(prevPhase.current)} />}
        {partyPreview !== null && <MegaCelebration idx={partyPreview} onDone={() => setPartyPreview(null)} />}
        {phase === "celebrate" && <MegaCelebration idx={idx} onDone={afterCelebrate} />}
        {phase === "lesson" && sub === "listen" && <ListenSub cfg={cfg} rate={rate} onUnderstand={() => { fire(); setSub("circle"); }} />}
        {phase === "lesson" && sub === "circle" && <CircleSub cfg={cfg} rate={rate} baseline={baseline} onComplete={() => setSub("triangle")} fireConfetti={fire} />}
        {phase === "lesson" && sub === "triangle" && <TriangleSub cfg={cfg} rate={rate} onComplete={() => setSub("match")} fireConfetti={fire} />}
        {phase === "lesson" && sub === "match" && <MatchSub words={matchWordsUpTo(idx)} rate={rate} onComplete={() => setSub("read")} />}
        {phase === "lesson" && sub === "read" && <ReadSub items={readItemsUpTo(idx)} intro={cfg.read} rate={rate} baseline={baseline} onComplete={() => setSub("readEval")} fireConfetti={fire} />}
        {phase === "lesson" && sub === "readMore" && <ReadSub items={readItemsUpTo(idx)} intro={cfg.read} rate={rate} baseline={baseline} onComplete={() => setSub("readEval")} fireConfetti={fire} extra={5} />}
        {phase === "lesson" && sub === "readEval" && <SelfEval onPick={(n) => setSub(n <= 2 ? "readMore" : "write")} />}
        {phase === "lesson" && sub === "write" && <WriteSub cfg={cfg} rate={rate} onComplete={() => setSub("dts")} fireConfetti={fire} />}
        {phase === "lesson" && sub === "dts" && <DTSSub idx={idx} rate={rate} onComplete={nextSentence} fireConfetti={fire} />}

        {phase === "finale" && <SelfEval onPick={() => setPhase("done")} />}
        {phase === "done" && <Cheer title="You did it — you read AND wrote the whole story in Chinese! 🎉" sub="Eight sentences: heard, circled, spoken, read, and written. That's real acquisition." onNext={() => { setPhase("cal"); setIdx(0); setSub("listen"); }} nextLabel="Run it again" />}
      </div>
    </div>
  );
}

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600;12..96,700&family=Nunito:ital,wght@0,400;0,600;0,700;0,800;1,400;1,600&family=Noto+Sans+SC:wght@500;600;700&display=swap');
* { box-sizing: border-box; }
.tone1 { color: #1F9D57; } .tone2 { color: #2563EB; } .tone3 { color: #7C3AED; } .tone4 { color: #DC2626; } .tone0 { color: #8A817C; }
.btnp { transition: transform .14s ease, box-shadow .14s ease; }
.btnp:hover { transform: translateY(-2px); } .btnp:active { transform: translateY(0); }
.opt:hover { box-shadow: 0 10px 22px -10px rgba(80,60,30,.35); }
.pulsemic { animation: pulsemic 1.4s ease-out infinite; }
@keyframes pulsemic { 0% { box-shadow: 0 0 0 0 rgba(220,38,38,.5); } 70% { box-shadow: 0 0 0 20px rgba(220,38,38,0); } 100% { box-shadow: 0 0 0 0 rgba(220,38,38,0); } }
.fadeUp { animation: fadeUp .45s cubic-bezier(.2,.7,.3,1) both; }
@keyframes fadeUp { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: none; } }
@keyframes bobble { 0%,100% { transform: translateY(0) rotate(-3deg); } 50% { transform: translateY(-5px) rotate(3deg); } }
@keyframes popIn { 0% { transform: scale(.8); opacity: 0; } 60% { transform: scale(1.06); } 100% { transform: scale(1); opacity: 1; } }
@keyframes dance { 0% { transform: rotate(-9deg) translateY(0) scale(1); } 25% { transform: rotate(9deg) translateY(-9px) scale(1.05); } 50% { transform: rotate(-9deg) translateY(0) scale(1); } 75% { transform: rotate(9deg) translateY(-9px) scale(1.05); } 100% { transform: rotate(-9deg) translateY(0) scale(1); } }
@keyframes confettiFall { from { transform: translate(0,0) rotate(0); opacity: 1; } to { transform: translate(var(--dx),110vh) rotate(var(--rot)); opacity: .15; } }
@keyframes discodance { 0% { transform: rotate(-10deg) translateY(0); } 18% { transform: rotate(8deg) translateY(-16px) scale(1.07); } 32% { transform: rotate(-8deg) translateY(0); } 50% { transform: rotate(170deg) translateY(-26px) scale(1.12); } 64% { transform: rotate(350deg) translateY(0) scale(1); } 80% { transform: rotate(342deg) translateY(-14px) scale(1.05); } 100% { transform: rotate(350deg) translateY(0); } }
@keyframes backupdance { 0%,100% { transform: translateX(0) translateY(0) rotate(-7deg); } 25% { transform: translateX(-9px) translateY(-10px) rotate(7deg); } 50% { transform: translateX(0) translateY(0) rotate(-7deg); } 75% { transform: translateX(9px) translateY(-10px) rotate(7deg); } }
@keyframes noteFloat { 0% { transform: translateY(0) rotate(-8deg); opacity: 0; } 15% { opacity: 1; } 100% { transform: translateY(-72px) rotate(10deg); opacity: 0; } }
@keyframes discoswing { 0%,100% { transform: rotate(-9deg); } 50% { transform: rotate(9deg); } }
@keyframes floorpulse { from { transform: scaleX(.9); opacity: .7; } to { transform: scaleX(1.08); opacity: 1; } }
@keyframes pulse2 { 0%,100% { transform: scale(1); } 50% { transform: scale(1.12); } }
@keyframes gateshake { 0%,100% { transform: translateX(0); } 20% { transform: translateX(-10px); } 40% { transform: translateX(9px); } 60% { transform: translateX(-6px); } 80% { transform: translateX(4px); } }
input[type=range] { cursor: pointer; }
`;
